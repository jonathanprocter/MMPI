# MMPI-2 Assessment Platform Documentation

## Overview
The MMPI-2 Assessment Platform is a web-based application for psychological assessment interpretation and report generation. It provides tools for entering MMPI-2 T-scores, generating detailed reports with gender-specific narratives, and visualizing profiles through interactive charts.

## Important Limitation
**This platform is designed as a T-score entry and reporting system only.**

The application does NOT include:
- The 567 MMPI-2 questionnaire items
- Logic to administer these items to clients
- Scoring algorithms to convert raw responses to T-scores

Users must administer the MMPI-2 assessment separately and manually enter the resulting T-scores into this system.

## Features
- Client information entry and management
- T-score entry for all MMPI-2 scales
- Interactive visualization of MMPI-2 profiles using Chart.js
- Gender-specific narrative interpretations
- Comprehensive psychological reports with diagnostic impressions
- Sample data for demonstration purposes

## Installation Instructions (For Local Development)

### Prerequisites
- Python 3.8 or higher
- pip package manager
- Virtual environment tool (recommended)

### Setup Steps
1. Clone the repository or download the source code
2. Navigate to the project directory
3. Create a virtual environment:
   ```
   python -m venv venv
   ```
4. Activate the virtual environment:
   - On Windows: `venv\Scripts\activate`
   - On macOS/Linux: `source venv/bin/activate`
5. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
6. Run the application:
   ```
   python src/main.py
   ```
7. Access the application at http://localhost:8080

## Directory Structure
```
mmpi_platform/
├── README.md
├── MANIFEST.md
├── requirements.txt
├── wsgi.py
└── src/
    ├── main.py              # Main application entry point
    ├── templates/           # HTML templates
    │   ├── index.html       # Homepage
    │   ├── client_info.html # Client information form
    │   ├── score_entry.html # T-score entry form
    │   ├── view_report.html # Report view
    │   └── error.html       # Error page
    └── reports/             # Generated reports directory
```

## Usage Instructions

### Starting a New Assessment
1. Access the platform using the URL
2. Click "Start New Assessment"
3. Enter client information (name, age, sex, etc.)
4. Enter T-scores for each MMPI-2 scale (these must be calculated separately)
5. Submit to generate the report

### Viewing Sample Reports
1. From the homepage, click "View Male Sample Report" or "View Female Sample Report"
2. The system will load pre-defined sample data
3. View the generated report with interactive charts

### Error Handling
If you encounter errors:
1. Return to the homepage and try again
2. Clear your session data using the "Clear Session Data" link
3. Try using the direct report access feature (when available)

## Self-Hosting Instructions

### Server Requirements
- Linux server with Python 3.8+ installed
- Web server (Nginx, Apache) with WSGI support
- Domain name (optional but recommended)

### Deployment Steps
1. Set up a Python virtual environment on your server
2. Install dependencies from requirements.txt
3. Configure your web server to proxy requests to the Flask application
4. Set environment variables:
   ```
   export SECRET_KEY="your_secure_secret_key"
   export FLASK_ENV="production"
   ```
5. Use a WSGI server like Gunicorn to run the application:
   ```
   gunicorn --bind 0.0.0.0:8080 wsgi:application
   ```

### Security Considerations
- Always use HTTPS in production
- Set a strong SECRET_KEY environment variable
- Implement proper authentication if deploying publicly
- Regularly update dependencies

## Known Issues and Limitations
1. **No Questionnaire Administration**: The platform does not administer the MMPI-2 questionnaire; it only accepts T-scores.
2. **Session Management**: The serverless environment has limitations with session handling, which may cause errors when accessing sample reports.
3. **Template Rendering**: Some template rendering issues may occur, particularly with the report view.
4. **Chart Rendering**: In some browsers, charts may not render correctly if JavaScript is disabled.

## Troubleshooting
1. **500 Internal Server Error**: This typically indicates a session management issue. Try clearing your browser cache and cookies, or use the "Clear Session Data" link.
2. **Missing Charts**: Ensure JavaScript is enabled in your browser.
3. **Form Submission Errors**: Verify that all required fields are completed before submission.

## Extending the Platform
To add MMPI-2 questionnaire functionality:
1. Create a database schema for storing the 567 MMPI-2 items
2. Develop templates for presenting questions to users
3. Implement logic for tracking responses and calculating raw scores
4. Add algorithms to convert raw scores to T-scores
5. Modify the workflow to include questionnaire administration before score entry

Note that the MMPI-2 is a copyrighted assessment tool, and proper licensing is required to administer it.

## Support
For issues or questions, please contact the development team.

---

© 2025 MMPI-2 Assessment Platform. For professional use only.

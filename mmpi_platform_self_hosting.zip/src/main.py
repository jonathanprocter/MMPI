"""
MMPI-2 Assessment Platform - Main Application Entry Point
This module provides the Flask application entry point for deployment.
"""

from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, jsonify
import os
import uuid
import json
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create Flask application with standard relative paths
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'mmpi2_assessment_platform_secret_key')
app.config['REPORT_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'reports')
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False

# Ensure report directory exists
if not os.path.exists(app.config['REPORT_FOLDER']):
    os.makedirs(app.config['REPORT_FOLDER'])

@app.route('/')
def index():
    """Home page."""
    logger.info("Accessing index page")
    return render_template('index.html')

@app.route('/client_info', methods=['GET', 'POST'])
def client_info():
    """Client information form."""
    if request.method == 'POST':
        # Store client info in session
        session['client_info'] = {
            'name': request.form.get('name'),
            'age': request.form.get('age'),
            'sex': request.form.get('sex'),
            'date': request.form.get('date') or datetime.now().strftime('%Y-%m-%d'),
            'referral_source': request.form.get('referral_source'),
            'reason_for_referral': request.form.get('reason_for_referral')
        }
        logger.info(f"Client info stored in session: {session['client_info']}")
        return redirect(url_for('score_entry'))
    return render_template('client_info.html')

@app.route('/score_entry', methods=['GET', 'POST'])
def score_entry():
    """Score entry form."""
    if request.method == 'POST':
        # Store scores in session
        session['scores'] = {
            'validity_scales': {
                'L': int(request.form.get('L', 50)),
                'F': int(request.form.get('F', 50)),
                'K': int(request.form.get('K', 50)),
                'VRIN': int(request.form.get('VRIN', 50)),
                'TRIN': int(request.form.get('TRIN', 50)),
                'Fb': int(request.form.get('Fb', 50)),
                'Fp': int(request.form.get('Fp', 50)),
                'FBS': int(request.form.get('FBS', 50)),
                'S': int(request.form.get('S', 50))
            },
            'clinical_scales': {
                'L': int(request.form.get('L', 50)),
                'F': int(request.form.get('F', 50)),
                'K': int(request.form.get('K', 50)),
                '1': int(request.form.get('1', 50)),
                '2': int(request.form.get('2', 50)),
                '3': int(request.form.get('3', 50)),
                '4': int(request.form.get('4', 50)),
                '5': int(request.form.get('5', 50)),
                '6': int(request.form.get('6', 50)),
                '7': int(request.form.get('7', 50)),
                '8': int(request.form.get('8', 50)),
                '9': int(request.form.get('9', 50)),
                '0': int(request.form.get('0', 50))
            },
            'content_scales': {
                'ANX': int(request.form.get('ANX', 50)),
                'FRS': int(request.form.get('FRS', 50)),
                'OBS': int(request.form.get('OBS', 50)),
                'DEP': int(request.form.get('DEP', 50)),
                'HEA': int(request.form.get('HEA', 50)),
                'BIZ': int(request.form.get('BIZ', 50)),
                'ANG': int(request.form.get('ANG', 50)),
                'CYN': int(request.form.get('CYN', 50)),
                'ASP': int(request.form.get('ASP', 50)),
                'TPA': int(request.form.get('TPA', 50)),
                'LSE': int(request.form.get('LSE', 50)),
                'SOD': int(request.form.get('SOD', 50)),
                'FAM': int(request.form.get('FAM', 50)),
                'WRK': int(request.form.get('WRK', 50)),
                'TRT': int(request.form.get('TRT', 50))
            },
            'rc_scales': {
                'RCd': int(request.form.get('RCd', 50)),
                'RC1': int(request.form.get('RC1', 50)),
                'RC2': int(request.form.get('RC2', 50)),
                'RC3': int(request.form.get('RC3', 50)),
                'RC4': int(request.form.get('RC4', 50)),
                'RC6': int(request.form.get('RC6', 50)),
                'RC7': int(request.form.get('RC7', 50)),
                'RC8': int(request.form.get('RC8', 50)),
                'RC9': int(request.form.get('RC9', 50))
            },
            'psy5_scales': {
                'AGGR': int(request.form.get('AGGR', 50)),
                'PSYC': int(request.form.get('PSYC', 50)),
                'DISC': int(request.form.get('DISC', 50)),
                'NEGE': int(request.form.get('NEGE', 50)),
                'INTR': int(request.form.get('INTR', 50))
            },
            'supplementary_scales': {
                'A': int(request.form.get('A', 50)),
                'R': int(request.form.get('R', 50)),
                'Es': int(request.form.get('Es', 50)),
                'Do': int(request.form.get('Do', 50)),
                'Re': int(request.form.get('Re', 50)),
                'Mt': int(request.form.get('Mt', 50)),
                'PK': int(request.form.get('PK', 50)),
                'MDS': int(request.form.get('MDS', 50)),
                'Ho': int(request.form.get('Ho', 50)),
                'O-H': int(request.form.get('O-H', 50)),
                'MAC-R': int(request.form.get('MAC-R', 50)),
                'APS': int(request.form.get('APS', 50)),
                'GM': int(request.form.get('GM', 50)),
                'GF': int(request.form.get('GF', 50))
            }
        }
        logger.info("Scores stored in session")
        return redirect(url_for('view_report'))
    return render_template('score_entry.html')

@app.route('/view_report')
def view_report():
    """View generated report."""
    try:
        logger.info("Accessing view_report")
        
        # Check if session data exists
        if 'client_info' not in session or 'scores' not in session:
            logger.warning("Session data missing, redirecting to index")
            return redirect(url_for('index'))
        
        client_info = session.get('client_info', {})
        scores = session.get('scores', {})
        
        logger.info(f"Rendering report with client_info: {client_info}")
        
        return render_template('view_report.html', 
                              client_info=client_info,
                              scores=scores)
    except Exception as e:
        logger.error(f"Error in view_report: {str(e)}")
        return render_template('error.html', error=str(e))

@app.route('/sample_data', methods=['GET'])
def sample_data():
    """Load sample data for demonstration."""
    try:
        logger.info("Loading male sample data")
        # Sample client info
        session['client_info'] = {
            'name': 'John Smith',
            'age': '35',
            'sex': 'male',
            'date': datetime.now().strftime('%Y-%m-%d'),
            'referral_source': 'Dr. Jane Doe',
            'reason_for_referral': 'Diagnostic clarification and treatment planning'
        }
        
        # Sample scores based on provided screenshots
        session['scores'] = {
            'validity_scales': {
                'L': 45, 'F': 51, 'K': 51, 'VRIN': 73, 'TRIN': 57, 'Fb': 51, 'Fp': 56, 'FBS': 43, 'S': 34
            },
            'clinical_scales': {
                'L': 45, 'F': 51, 'K': 51, '1': 51, '2': 51, '3': 51, '4': 68, '5': 62, '6': 53, '7': 44, '8': 56, '9': 56, '0': 44
            },
            'content_scales': {
                'ANX': 62, 'FRS': 67, 'OBS': 53, 'DEP': 55, 'HEA': 56, 'BIZ': 57, 'ANG': 63, 'CYN': 56, 'ASP': 53, 'TPA': 60, 'LSE': 53, 'SOD': 49, 'FAM': 66, 'WRK': 61, 'TRT': 56
            },
            'rc_scales': {
                'RCd': 54, 'RC1': 63, 'RC2': 46, 'RC3': 56, 'RC4': 71, 'RC6': 62, 'RC7': 52, 'RC8': 59, 'RC9': 61
            },
            'psy5_scales': {
                'AGGR': 74, 'PSYC': 49, 'DISC': 51, 'NEGE': 64, 'INTR': 43
            },
            'supplementary_scales': {
                'A': 51, 'R': 36, 'Es': 38, 'Do': 38, 'Re': 37, 'Mt': 57, 'PK': 58, 'MDS': 69, 'Ho': 58, 'O-H': 45, 'MAC-R': 55, 'APS': 65, 'GM': 41, 'GF': 30
            }
        }
        
        logger.info("Sample data loaded, redirecting to view_report")
        return redirect(url_for('view_report'))
    except Exception as e:
        logger.error(f"Error in sample_data: {str(e)}")
        return render_template('error.html', error=str(e))

@app.route('/female_sample_data', methods=['GET'])
def female_sample_data():
    """Load female sample data for demonstration."""
    try:
        logger.info("Loading female sample data")
        # Sample client info
        session['client_info'] = {
            'name': 'Jane Smith',
            'age': '35',
            'sex': 'female',
            'date': datetime.now().strftime('%Y-%m-%d'),
            'referral_source': 'Dr. John Doe',
            'reason_for_referral': 'Diagnostic clarification and treatment planning'
        }
        
        # Sample scores based on provided screenshots (same T-scores as male sample)
        session['scores'] = {
            'validity_scales': {
                'L': 45, 'F': 51, 'K': 51, 'VRIN': 73, 'TRIN': 57, 'Fb': 51, 'Fp': 56, 'FBS': 43, 'S': 34
            },
            'clinical_scales': {
                'L': 45, 'F': 51, 'K': 51, '1': 51, '2': 51, '3': 51, '4': 68, '5': 62, '6': 53, '7': 44, '8': 56, '9': 56, '0': 44
            },
            'content_scales': {
                'ANX': 62, 'FRS': 67, 'OBS': 53, 'DEP': 55, 'HEA': 56, 'BIZ': 57, 'ANG': 63, 'CYN': 56, 'ASP': 53, 'TPA': 60, 'LSE': 53, 'SOD': 49, 'FAM': 66, 'WRK': 61, 'TRT': 56
            },
            'rc_scales': {
                'RCd': 54, 'RC1': 63, 'RC2': 46, 'RC3': 56, 'RC4': 71, 'RC6': 62, 'RC7': 52, 'RC8': 59, 'RC9': 61
            },
            'psy5_scales': {
                'AGGR': 74, 'PSYC': 49, 'DISC': 51, 'NEGE': 64, 'INTR': 43
            },
            'supplementary_scales': {
                'A': 51, 'R': 36, 'Es': 38, 'Do': 38, 'Re': 37, 'Mt': 57, 'PK': 58, 'MDS': 69, 'Ho': 58, 'O-H': 45, 'MAC-R': 55, 'APS': 65, 'GM': 41, 'GF': 30
            }
        }
        
        logger.info("Female sample data loaded, redirecting to view_report")
        return redirect(url_for('view_report'))
    except Exception as e:
        logger.error(f"Error in female_sample_data: {str(e)}")
        return render_template('error.html', error=str(e))

@app.route('/clear_session', methods=['GET'])
def clear_session():
    """Clear session data."""
    try:
        logger.info("Clearing session data")
        session.clear()
        return redirect(url_for('index'))
    except Exception as e:
        logger.error(f"Error clearing session: {str(e)}")
        return render_template('error.html', error=str(e))

@app.route('/direct_report')
def direct_report():
    """Direct access to report with hardcoded data (no session dependency)."""
    try:
        logger.info("Accessing direct report (no session dependency)")
        
        # Hardcoded client info
        client_info = {
            'name': 'John Smith',
            'age': '35',
            'sex': 'male',
            'date': datetime.now().strftime('%Y-%m-%d'),
            'referral_source': 'Dr. Jane Doe',
            'reason_for_referral': 'Diagnostic clarification and treatment planning'
        }
        
        # Hardcoded scores
        scores = {
            'validity_scales': {
                'L': 45, 'F': 51, 'K': 51, 'VRIN': 73, 'TRIN': 57, 'Fb': 51, 'Fp': 56, 'FBS': 43, 'S': 34
            },
            'clinical_scales': {
                'L': 45, 'F': 51, 'K': 51, '1': 51, '2': 51, '3': 51, '4': 68, '5': 62, '6': 53, '7': 44, '8': 56, '9': 56, '0': 44
            },
            'content_scales': {
                'ANX': 62, 'FRS': 67, 'OBS': 53, 'DEP': 55, 'HEA': 56, 'BIZ': 57, 'ANG': 63, 'CYN': 56, 'ASP': 53, 'TPA': 60, 'LSE': 53, 'SOD': 49, 'FAM': 66, 'WRK': 61, 'TRT': 56
            },
            'rc_scales': {
                'RCd': 54, 'RC1': 63, 'RC2': 46, 'RC3': 56, 'RC4': 71, 'RC6': 62, 'RC7': 52, 'RC8': 59, 'RC9': 61
            },
            'psy5_scales': {
                'AGGR': 74, 'PSYC': 49, 'DISC': 51, 'NEGE': 64, 'INTR': 43
            },
            'supplementary_scales': {
                'A': 51, 'R': 36, 'Es': 38, 'Do': 38, 'Re': 37, 'Mt': 57, 'PK': 58, 'MDS': 69, 'Ho': 58, 'O-H': 45, 'MAC-R': 55, 'APS': 65, 'GM': 41, 'GF': 30
            }
        }
        
        return render_template('view_report.html', 
                              client_info=client_info,
                              scores=scores)
    except Exception as e:
        logger.error(f"Error in direct_report: {str(e)}")
        return render_template('error.html', error=str(e))

# Required for Flask deployment
def create_app():
    return app

# For local development
if __name__ == "__main__":
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)

# MMPI-2 Assessment Platform - File Manifest

This document provides a complete list of required files for self-hosting the MMPI-2 Assessment Platform.

## Important Limitation
**The MMPI-2 Assessment Platform is designed as a T-score entry and reporting system only.**

This platform does not include:
- The 567 MMPI-2 questionnaire items
- Logic to administer these items to clients
- Scoring algorithms to convert raw responses to T-scores

Users are expected to administer the MMPI-2 assessment separately and manually enter the resulting T-scores into this system.

## Core Application Files

### Root Directory
- `README.md` - Documentation and usage instructions
- `requirements.txt` - Python dependencies
- `wsgi.py` - WSGI entry point for deployment

### Source Directory (`src/`)
- `main.py` - Main application entry point with all Flask routes

### Templates (`src/templates/`)
- `index.html` - Homepage
- `client_info.html` - Client information entry form
- `score_entry.html` - T-score entry form
- `view_report.html` - Report view template
- `error.html` - Error page template

### Static Files
- No custom static files are required for basic functionality
- The application uses CDN-hosted Bootstrap and JavaScript libraries

## Directory Structure
```
mmpi_platform/
├── README.md
├── MANIFEST.md
├── requirements.txt
├── wsgi.py
└── src/
    ├── main.py
    ├── templates/
    │   ├── index.html
    │   ├── client_info.html
    │   ├── score_entry.html
    │   ├── view_report.html
    │   └── error.html
    └── reports/
        └── (empty directory for generated reports)
```

## Self-Hosting Requirements
1. Python 3.8 or higher
2. Flask and dependencies (specified in requirements.txt)
3. Web server capable of hosting WSGI applications (e.g., Gunicorn, uWSGI)
4. Reverse proxy server (recommended, e.g., Nginx, Apache)

## Deployment Checklist
- [ ] Clone or download all files in the manifest
- [ ] Create a Python virtual environment
- [ ] Install dependencies from requirements.txt
- [ ] Configure web server to serve the WSGI application
- [ ] Set appropriate permissions for the reports directory
- [ ] Configure environment variables (SECRET_KEY, etc.)
- [ ] Test all routes and functionality

## Adding MMPI-2 Questionnaire Functionality
To extend this platform with actual MMPI-2 questionnaire administration:

1. Create a database schema for storing the 567 MMPI-2 items
2. Develop templates for presenting questions to users
3. Implement logic for tracking responses and calculating raw scores
4. Add algorithms to convert raw scores to T-scores
5. Modify the workflow to include questionnaire administration before score entry

Note that the MMPI-2 is a copyrighted assessment tool, and proper licensing is required to administer it.

"""
Graph utility functions for MMPI-2 Assessment Platform
Pure Python implementation without numpy dependency
"""

def generate_x_positions(length):
    """Generate evenly spaced x positions for plotting"""
    return list(range(length))

def calculate_statistics(data):
    """Calculate basic statistics for data"""
    if not data:
        return None, None, None
    
    mean = sum(data) / len(data)
    
    # Calculate variance
    variance = sum((x - mean) ** 2 for x in data) / len(data)
    
    # Calculate standard deviation
    std_dev = variance ** 0.5
    
    return mean, variance, std_dev

def normalize_data(data, min_val=0, max_val=100):
    """Normalize data to a specific range"""
    if not data:
        return []
    
    data_min = min(data)
    data_max = max(data)
    
    if data_max == data_min:
        return [min_val for _ in data]
    
    normalized = []
    for value in data:
        normalized_value = ((value - data_min) / (data_max - data_min)) * (max_val - min_val) + min_val
        normalized.append(normalized_value)
    
    return normalized

def moving_average(data, window_size=3):
    """Calculate moving average of data"""
    if not data or window_size <= 0:
        return []
    
    result = []
    for i in range(len(data)):
        start = max(0, i - window_size + 1)
        window = data[start:i+1]
        avg = sum(window) / len(window)
        result.append(avg)
    
    return result

def linear_interpolation(x, x0, y0, x1, y1):
    """Linear interpolation between two points"""
    if x1 == x0:
        return y0
    return y0 + (x - x0) * (y1 - y0) / (x1 - x0)

def interpolate_data(x_values, y_values, new_x_values):
    """Interpolate y values for new x values"""
    if not x_values or not y_values or not new_x_values:
        return []
    
    result = []
    for x in new_x_values:
        # Find the two closest x values
        if x <= x_values[0]:
            result.append(y_values[0])
        elif x >= x_values[-1]:
            result.append(y_values[-1])
        else:
            for i in range(len(x_values) - 1):
                if x_values[i] <= x < x_values[i + 1]:
                    y = linear_interpolation(x, x_values[i], y_values[i], x_values[i + 1], y_values[i + 1])
                    result.append(y)
                    break
    
    return result

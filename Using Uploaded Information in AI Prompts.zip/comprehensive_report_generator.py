"""
Comprehensive Report Generator for MMPI-2 assessments.
This module creates detailed reports with personalized narratives and web-compatible graphics.
"""

import os
import json
import datetime
from jinja2 import Template
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

class ComprehensiveReportGenerator:
    """
    Generates comprehensive MMPI-2 reports with personalized narratives and web-compatible graphics.
    """
    
    def __init__(self, output_dir):
        """
        Initialize the report generator.
        
        Args:
            output_dir (str): Directory to save generated reports
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Import interpretation modules
        from src.interpretation.validity_scales import get_validity_scale_interpretation
        from src.interpretation.clinical_scales import get_clinical_scale_interpretation
        from src.interpretation.harris_lingoes_subscales import get_harris_lingoes_interpretation
        from src.interpretation.content_scales import get_content_scale_interpretation
        from src.interpretation.content_component_scales import get_content_component_interpretation
        from src.interpretation.rc_scales import get_rc_scale_interpretation
        from src.interpretation.psy5_scales import get_psy5_scale_interpretation
        from src.interpretation.supplementary_scales import get_supplementary_scale_interpretation
        from src.interpretation.scale_interpretations import get_two_point_code_interpretation
        from src.interpretation.dsm5tr_decision_trees import get_diagnostic_impressions
        
        # Store interpretation functions
        self.interpretation_functions = {
            'validity': get_validity_scale_interpretation,
            'clinical': get_clinical_scale_interpretation,
            'harris_lingoes': get_harris_lingoes_interpretation,
            'content': get_content_scale_interpretation,
            'content_component': get_content_component_interpretation,
            'rc': get_rc_scale_interpretation,
            'psy5': get_psy5_scale_interpretation,
            'supplementary': get_supplementary_scale_interpretation,
            'two_point_code': get_two_point_code_interpretation,
            'diagnostic': get_diagnostic_impressions
        }
        
        # RC Scale full names mapping
        self.rc_scales_full_names = {
            'RCd': 'Demoralization',
            'RC1': 'Somatic Complaints',
            'RC2': 'Low Positive Emotions',
            'RC3': 'Cynicism',
            'RC4': 'Antisocial Behavior',
            'RC6': 'Ideas of Persecution',
            'RC7': 'Dysfunctional Negative Emotions',
            'RC8': 'Aberrant Experiences',
            'RC9': 'Hypomanic Activation'
        }
    
    def generate_report(self, scores, client_info):
        """
        Generate comprehensive MMPI-2 report.
        
        Args:
            scores (dict): Dictionary containing all scale scores
            client_info (dict): Dictionary containing client information
            
        Returns:
            dict: Dictionary containing report data and file paths
        """
        # Create report data structure
        report_data = {
            'client_info': client_info,
            'scores': scores,
            'interpretations': {},
            'date_generated': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'rc_scales_full_names': self.rc_scales_full_names
        }
        
        # Get client name and sex for personalization
        client_name = client_info.get('name', 'The client')
        client_sex = client_info.get('sex', 'female')
        
        # Generate interpretations for each scale family
        report_data['interpretations']['validity'] = self._get_scale_family_interpretations(
            'validity', scores.get('validity_scales', {}), client_name, client_sex
        )
        
        report_data['interpretations']['clinical'] = self._get_scale_family_interpretations(
            'clinical', scores.get('clinical_scales', {}), client_name, client_sex
        )
        
        report_data['interpretations']['harris_lingoes'] = self._get_scale_family_interpretations(
            'harris_lingoes', scores.get('harris_lingoes_subscales', {}), client_name, client_sex
        )
        
        report_data['interpretations']['content'] = self._get_scale_family_interpretations(
            'content', scores.get('content_scales', {}), client_name, client_sex
        )
        
        report_data['interpretations']['rc'] = self._get_scale_family_interpretations(
            'rc', scores.get('rc_scales', {}), client_name, client_sex
        )
        
        report_data['interpretations']['psy5'] = self._get_scale_family_interpretations(
            'psy5', scores.get('psy5_scales', {}), client_name, client_sex
        )
        
        report_data['interpretations']['supplementary'] = self._get_scale_family_interpretations(
            'supplementary', scores.get('supplementary_scales', {}), client_name, client_sex
        )
        
        # Generate two-point code interpretation
        clinical_scores = scores.get('clinical_scales', {})
        report_data['interpretations']['two_point_code'] = self._get_two_point_code_interpretation(
            clinical_scores, client_name, client_sex
        )
        
        # Generate diagnostic impressions
        all_scores = {
            'validity': scores.get('validity_scales', {}),
            'clinical': scores.get('clinical_scales', {}),
            'content': scores.get('content_scales', {}),
            'rc': scores.get('rc_scales', {})
        }
        report_data['interpretations']['diagnostic'] = self._get_diagnostic_impressions(
            all_scores, client_name, client_sex
        )
        
        # Generate treatment recommendations
        report_data['interpretations']['treatment'] = self._generate_treatment_recommendations(
            report_data['interpretations']['diagnostic'], client_name, client_sex
        )
        
        # Generate report files
        report_files = self._generate_report_files(report_data)
        
        # Return report data and file paths
        return {
            'data': report_data,
            'files': report_files
        }
    
    def _get_scale_family_interpretations(self, scale_family, scores, client_name, client_sex):
        """
        Get interpretations for a scale family.
        
        Args:
            scale_family (str): Scale family name
            scores (dict): Dictionary of scale scores
            client_name (str): Client's name for personalization
            client_sex (str): Client's sex for appropriate interpretation
            
        Returns:
            dict: Dictionary of scale interpretations
        """
        interpretations = {}
        
        if scale_family in self.interpretation_functions:
            interpretation_func = self.interpretation_functions[scale_family]
            
            for scale, score in scores.items():
                # Get interpretation for this scale
                interpretation = interpretation_func(scale, score, client_sex)
                
                # Personalize interpretation with client's name
                if interpretation:
                    interpretation = self._personalize_narrative(interpretation, client_name, client_sex)
                
                interpretations[scale] = {
                    'score': score,
                    'interpretation': interpretation
                }
                
                # Add full name for RC scales
                if scale_family == 'rc' and scale in self.rc_scales_full_names:
                    interpretations[scale]['full_name'] = self.rc_scales_full_names[scale]
        
        return interpretations
    
    def _get_two_point_code_interpretation(self, clinical_scores, client_name, client_sex):
        """
        Get two-point code interpretation.
        
        Args:
            clinical_scores (dict): Dictionary of clinical scale scores
            client_name (str): Client's name for personalization
            client_sex (str): Client's sex for appropriate interpretation
            
        Returns:
            dict: Two-point code interpretation data
        """
        # Filter out non-clinical scales
        clinical_only = {}
        for scale, score in clinical_scores.items():
            if scale in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']:
                clinical_only[scale] = score
        
        # Find two highest scales
        if len(clinical_only) < 2:
            return {
                'code': None,
                'interpretation': "Insufficient clinical scale data to determine two-point code."
            }
        
        # Sort scales by score (descending)
        sorted_scales = sorted(clinical_only.items(), key=lambda x: x[1], reverse=True)
        
        # Get top two scales
        top_two = sorted_scales[:2]
        
        # Create code (e.g., "2-7" or "7-2")
        code = f"{top_two[0][0]}-{top_two[1][0]}"
        
        # Get interpretation
        interpretation = self.interpretation_functions['two_point_code'](code, client_sex)
        
        # Personalize interpretation
        if interpretation:
            interpretation = self._personalize_narrative(interpretation, client_name, client_sex)
        
        return {
            'code': code,
            'scales': [top_two[0][0], top_two[1][0]],
            'scores': [top_two[0][1], top_two[1][1]],
            'interpretation': interpretation
        }
    
    def _get_diagnostic_impressions(self, all_scores, client_name, client_sex):
        """
        Get diagnostic impressions based on DSM-5-TR decision trees.
        
        Args:
            all_scores (dict): Dictionary of all scale scores
            client_name (str): Client's name for personalization
            client_sex (str): Client's sex for appropriate interpretation
            
        Returns:
            dict: Diagnostic impressions data
        """
        # Get diagnostic impressions
        diagnostic_data = self.interpretation_functions['diagnostic'](all_scores, client_sex)
        
        # Personalize narratives
        if 'primary_diagnosis' in diagnostic_data and diagnostic_data['primary_diagnosis']:
            diagnostic_data['primary_diagnosis'] = self._personalize_narrative(
                diagnostic_data['primary_diagnosis'], client_name, client_sex
            )
        
        if 'differential_diagnoses' in diagnostic_data and diagnostic_data['differential_diagnoses']:
            personalized_differentials = []
            for diff in diagnostic_data['differential_diagnoses']:
                personalized_differentials.append(
                    self._personalize_narrative(diff, client_name, client_sex)
                )
            diagnostic_data['differential_diagnoses'] = personalized_differentials
        
        if 'rule_outs' in diagnostic_data and diagnostic_data['rule_outs']:
            personalized_rule_outs = []
            for rule_out in diagnostic_data['rule_outs']:
                personalized_rule_outs.append(
                    self._personalize_narrative(rule_out, client_name, client_sex)
                )
            diagnostic_data['rule_outs'] = personalized_rule_outs
        
        return diagnostic_data
    
    def _generate_treatment_recommendations(self, diagnostic_data, client_name, client_sex):
        """
        Generate treatment recommendations based on diagnostic impressions.
        
        Args:
            diagnostic_data (dict): Diagnostic impressions data
            client_name (str): Client's name for personalization
            client_sex (str): Client's sex for appropriate recommendations
            
        Returns:
            dict: Treatment recommendations data
        """
        # Default recommendations
        recommendations = {
            'general': "A comprehensive treatment approach is recommended based on the assessment results.",
            'specific': []
        }
        
        # Add specific recommendations based on primary diagnosis
        if 'primary_diagnosis' in diagnostic_data and diagnostic_data['primary_diagnosis']:
            primary = diagnostic_data.get('primary_diagnosis', '').lower()
            
            if 'depression' in primary or 'mood disorder' in primary:
                recommendations['specific'].append(
                    f"Consider evidence-based treatments for depression, such as cognitive-behavioral therapy (CBT) or interpersonal therapy (IPT). Medication evaluation may be warranted given the severity of symptoms."
                )
            
            if 'anxiety' in primary:
                recommendations['specific'].append(
                    f"Anxiety-focused cognitive-behavioral therapy with exposure components is recommended. Relaxation training and mindfulness practices may also be beneficial."
                )
            
            if 'trauma' in primary or 'ptsd' in primary:
                recommendations['specific'].append(
                    f"Trauma-focused therapy approaches such as Prolonged Exposure (PE) or Cognitive Processing Therapy (CPT) are indicated. Ensure treatment is delivered in a safe, supportive environment with attention to therapeutic alliance."
                )
            
            if 'personality' in primary:
                recommendations['specific'].append(
                    f"Long-term therapy focused on interpersonal patterns and emotional regulation is recommended. Dialectical Behavior Therapy (DBT) or Schema Therapy may be particularly beneficial."
                )
            
            if 'psychotic' in primary or 'schizophrenia' in primary:
                recommendations['specific'].append(
                    f"Integrated treatment approach combining medication management, psychoeducation, and supportive therapy is recommended. Family involvement and psychosocial rehabilitation should be considered."
                )
            
            if 'substance' in primary or 'alcohol' in primary:
                recommendations['specific'].append(
                    f"Substance use treatment combining motivational enhancement, cognitive-behavioral approaches, and relapse prevention strategies is indicated. Consider evaluation for medication-assisted treatment if appropriate."
                )
        
        # If no specific recommendations were generated, add general ones
        if not recommendations['specific']:
            recommendations['specific'] = [
                f"Individual therapy focusing on identified areas of concern is recommended.",
                f"Regular monitoring of symptoms and treatment progress is advised.",
                f"Consideration of adjunctive group therapy may provide additional support and skill development."
            ]
        
        # Personalize recommendations
        recommendations['general'] = self._personalize_narrative(
            recommendations['general'], client_name, client_sex
        )
        
        personalized_specific = []
        for rec in recommendations['specific']:
            personalized_specific.append(
                self._personalize_narrative(rec, client_name, client_sex)
            )
        recommendations['specific'] = personalized_specific
        
        return recommendations
    
    def _personalize_narrative(self, narrative, client_name, client_sex):
        """
        Personalize narrative by replacing generic gender references with client's name.
        
        Args:
            narrative (str): Original narrative text
            client_name (str): Client's name
            client_sex (str): Client's sex
            
        Returns:
     
(Content truncated due to size limit. Use line ranges to read in chunks)
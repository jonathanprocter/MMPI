"""
Clinical Scales Interpretations for MMPI-2.

This module provides detailed interpretations for MMPI-2 Clinical Scales
based on T-score ranges and gender.
"""

# Clinical Scale Interpretations Dictionary
CLINICAL_SCALES_INTERPRETATIONS = {
    "Hs": {
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male respondent reports few physical complaints and appears to be in good health. He likely has a positive body image and normal concern about bodily functions. He presents as energetic, optimistic, and physically capable."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male respondent reports a moderate level of physical concerns that fall within normal limits. He is likely reasonably attentive to his health without excessive preoccupation. His physical complaints are generally realistic and appropriate to his actual health status."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This male respondent reports a significant number of somatic complaints and physical symptoms. He may be preoccupied with his bodily functions and health status. These concerns may represent actual physical problems, a tendency to express psychological distress through physical channels, or both. He may use physical complaints to avoid addressing emotional or interpersonal issues."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This male respondent reports numerous physical complaints and appears highly preoccupied with bodily functions and health concerns. He likely presents as physically uncomfortable, fatigued, and limited by his perceived health problems. His somatic preoccupation may serve to avoid psychological issues or difficult life situations. He may have a long history of medical treatment with minimal relief of symptoms. His interpersonal style may involve seeking attention and support through the expression of physical complaints."
                }
            ]
        },
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female respondent reports few physical complaints and appears to be in good health. She likely has a positive body image and normal concern about bodily functions. She presents as energetic, optimistic, and physically capable."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female respondent reports a moderate level of physical concerns that fall within normal limits. She is likely reasonably attentive to her health without excessive preoccupation. Her physical complaints are generally realistic and appropriate to her actual health status."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This female respondent reports a significant number of somatic complaints and physical symptoms. She may be preoccupied with her bodily functions and health status. These concerns may represent actual physical problems, a tendency to express psychological distress through physical channels, or both. She may use physical complaints to avoid addressing emotional or interpersonal issues."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This female respondent reports numerous physical complaints and appears highly preoccupied with bodily functions and health concerns. She likely presents as physically uncomfortable, fatigued, and limited by her perceived health problems. Her somatic preoccupation may serve to avoid psychological issues or difficult life situations. She may have a long history of medical treatment with minimal relief of symptoms. Her interpersonal style may involve seeking attention and support through the expression of physical complaints."
                }
            ]
        }
    },
    "D": {
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male respondent reports minimal depressive symptoms and generally positive mood. He likely experiences satisfaction with his life circumstances and maintains a hopeful outlook. He appears to have adequate energy for daily activities and engagement with others."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male respondent reports some depressive symptoms that fall within normal limits. He may occasionally experience periods of sadness or discouragement, but these do not significantly impact his functioning. He maintains adequate interest and engagement in most activities."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This male respondent reports significant depressive symptoms, including sadness, pessimism, and reduced enjoyment of activities. He may feel overwhelmed by his life circumstances and have difficulty seeing positive outcomes for his problems. His energy level and motivation are likely diminished, affecting his ability to function effectively in some areas of life."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This male respondent reports severe depressive symptoms, including persistent sadness, hopelessness, and anhedonia. He likely experiences significant fatigue, reduced motivation, and difficulty concentrating. His self-esteem is probably poor, with feelings of worthlessness and possibly guilt. He may have thoughts about death or suicide. His interpersonal functioning is likely impaired, with withdrawal from social activities and relationships. His overall functioning is significantly compromised by his depressive symptoms."
                }
            ]
        },
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female respondent reports minimal depressive symptoms and generally positive mood. She likely experiences satisfaction with her life circumstances and maintains a hopeful outlook. She appears to have adequate energy for daily activities and engagement with others."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female respondent reports some depressive symptoms that fall within normal limits. She may occasionally experience periods of sadness or discouragement, but these do not significantly impact her functioning. She maintains adequate interest and engagement in most activities."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This female respondent reports significant depressive symptoms, including sadness, pessimism, and reduced enjoyment of activities. She may feel overwhelmed by her life circumstances and have difficulty seeing positive outcomes for her problems. Her energy level and motivation are likely diminished, affecting her ability to function effectively in some areas of life."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This female respondent reports severe depressive symptoms, including persistent sadness, hopelessness, and anhedonia. She likely experiences significant fatigue, reduced motivation, and difficulty concentrating. Her self-esteem is probably poor, with feelings of worthlessness and possibly guilt. She may have thoughts about death or suicide. Her interpersonal functioning is likely impaired, with withdrawal from social activities and relationships. Her overall functioning is significantly compromised by her depressive symptoms."
                }
            ]
        }
    },
    "Hy": {
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male respondent appears psychologically insightful and willing to acknowledge personal problems. He likely recognizes and accepts negative emotions as part of normal experience. He may be somewhat skeptical or cynical in his worldview."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male respondent shows a normal balance between psychological awareness and the use of denial. He generally acknowledges emotional difficulties while maintaining a reasonably positive outlook. His approach to problems is likely practical and straightforward."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This male respondent shows significant use of denial and repression to manage anxiety. He may have limited insight into his psychological functioning and the motivations behind his behavior. He likely presents as socially conforming and may be uncomfortable with expressions of negative emotions, particularly anger. Under stress, he may develop somatic symptoms that have no clear medical explanation."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This male respondent shows extensive use of denial and repression, with poor insight into his psychological functioning. He likely presents as naive, socially conforming, and overly optimistic. He strongly resists acknowledging psychological problems or negative emotions, particularly anger. Under stress, he is prone to developing physical symptoms without medical explanation (conversion symptoms). His interpersonal style may be superficially engaging but lacks genuine emotional depth. He may be quite suggestible and dependent in relationships."
                }
            ]
        },
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female respondent appears psychologically insightful and willing to acknowledge personal problems. She likely recognizes and accepts negative emotions as part of normal experience. She may be somewhat skeptical or cynical in her worldview."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female respondent shows a normal balance between psychological awareness and the use of denial. She generally acknowledges emotional difficulties while maintaining a reasonably positive outlook. Her approach to problems is likely practical and straightforward."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This female respondent shows significant use of denial and repression to manage anxiety. She may have limited insight into her psychological functioning and the motivations behind her behavior. She likely presents as socially conforming and may be uncomfortable with expressions of negative emotions, particularly anger. Under stress, she may develop somatic symptoms that have no clear medical explanation."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This female respondent shows extensive use of denial and repression, with poor insight into her psychological functioning. She likely presents as naive, socially conforming, and overly optimistic. She strongly resists acknowledging psychological problems or negative emotions, particularly anger. Under stress, she is prone to developing physical symptoms without medical explanation (conversion symptoms). Her interpersonal style may be superficially engaging but lacks genuine emotional depth. She may be quite suggestible and dependent in relationships."
                }
            ]
        }
    },
    "Pd": {
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male respondent reports conventional attitudes and good adherence to social norms. He likely respects authority and follows rules without significant resentment. His family relationships appear positive, and he shows good impulse control."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male respondent shows a normal balance between conformity and autonomy. He may occasionally question authority or bend rules, but generally functions within social expectations. His family relationships and impulse control are within normal limits."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This male respondent shows significant problems with authority and social norms. He may have a history of conflict with family members and authority figures. His behavior is likely impulsive at times, with poor consideration of long-term consequences. He may experience dissatisfaction with his life circumstances but blame others rather than take responsibility for his problems."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This male respondent shows a pattern of chronic conflict with authority and rejection of social norms. He likely has a history of significant family problems and may engage in antisocial or illegal behaviors. His interpersonal relationships are probably characterized by exploitation, manipulation, and lack of genuine empathy. He shows poor impulse control and minimal consideration of long-term consequences. He experiences chronic anger and resentment but lacks insight into his contribution to his problems. His judgment is poor, particularly in social situations."
                }
            ]
        },
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female respondent reports conventional attitudes and good adherence to social norms. She likely respects authority and follows rules without significant resentment. Her family relationships appear positive, and she shows good impulse control."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female respondent shows a normal balance between conformity and autonomy. She may occasionally question authority or bend rules, but generally functions within social expectations. Her family relationships and impulse control are within normal limits."
                },
                {
                    "range": [65, 74],
                    "interpretation": "This female respondent shows significant problems with authority and social norms. She may have a history of conflict with family members and authority figures. Her behavior is likely impulsive at times, with poor consideration of long-term consequences. She may experience dissatisfaction with her life circumstances but blame others rather than take responsibility for her problems."
                },
                {
                    "range": [75, 120],
                    "interpretation": "This female respondent shows a pattern of chronic conflict with authority and rejection of social norms. She likely has a history of significant family problems and may engage in antisocial or illegal behaviors. Her interpersonal relationships are probably characterized by exploitation, manipulation, and lack of genuine empathy. She shows poor impulse control and minimal consideration of long-term consequences. She experiences chronic anger and resentment but lacks insight into her contr
(Content truncated due to size limit. Use line ranges to read in chunks)
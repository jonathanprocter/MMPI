"""
Scale Interpretations Module

This module provides the central function for retrieving scale interpretations
based on scale name, T-score, and gender.
"""

# Import all scale interpretation dictionaries
from src.interpretation.clinical_scales import CLINICAL_SCALES_INTERPRETATIONS
from src.interpretation.rc_scales import get_rc_scale_interpretation
from src.interpretation.content_scales import CONTENT_SCALES_INTERPRETATIONS
from src.interpretation.content_component_scales import get_content_component_scale_interpretation
from src.interpretation.psy5_scales import PSY5_SCALES_INTERPRETATIONS
from src.interpretation.harris_lingoes_subscales import HARRIS_LINGOES_SUBSCALES_INTERPRETATIONS
from src.interpretation.supplementary_scales import SUPPLEMENTARY_SCALES_INTERPRETATIONS
from src.interpretation.validity_scales import VALIDITY_SCALES_INTERPRETATIONS

# Function to get the appropriate interpretation for a scale based on its T-score
def get_scale_interpretation(scale_name, t_score, raw_score=None, gender=None, scale_type=None):
    """
    Get the interpretation for a scale based on its T-score and gender.
    
    Args:
        scale_name (str): The name of the scale (e.g., "1", "2", "Hs", "D")
        t_score (float or str): The T-score for the scale
        raw_score (float or str, optional): The raw score for the scale, used for additional context
        gender (str, optional): The gender of the respondent ("Male" or "Female")
        scale_type (str, optional): The type of scale (e.g., "VALIDITY", "CLINICAL")
    
    Returns:
        str: The interpretation for the scale based on its T-score and gender
    """
    # Handle non-numeric t_score
    try:
        t_score = float(t_score) if t_score is not None else 0
    except (ValueError, TypeError):
        # If t_score cannot be converted to float, return a message indicating invalid score
        return f"T-score for {scale_name} is not a numeric value; interpretation cannot be provided."
    
    # Map numeric clinical scale codes to their text equivalents
    clinical_scale_map = {
        "1": "Hs", "2": "D", "3": "Hy", "4": "Pd", "5": "Mf",
        "6": "Pa", "7": "Pt", "8": "Sc", "9": "Ma", "0": "Si"
    }
    
    # Apply mapping for clinical scales
    if scale_name in clinical_scale_map:
        lookup_name = clinical_scale_map[scale_name]
    else:
        lookup_name = scale_name
    
    # Use specialized interpretation functions for RC and Content Component scales
    if lookup_name.startswith("RC") or lookup_name == "RCd":
        return get_rc_scale_interpretation(lookup_name, t_score, gender)
    
    elif any(lookup_name.startswith(prefix) for prefix in ["ANX", "FRS", "OBS", "DEP", "HEA", "BIZ", "ANG", "CYN", "ASP", "TPA", "LSE", "SOD", "FAM", "WRK", "TRT"]) and len(lookup_name) > 3:
        return get_content_component_scale_interpretation(lookup_name, t_score, gender)
    
    # Determine which dictionary to use based on scale_name or scale_type
    if lookup_name in ["?", "L", "F", "K", "Fb", "Fp", "FBS", "VRIN", "TRIN", "S"] or (scale_type == "VALIDITY"):
        interpretation_dict = VALIDITY_SCALES_INTERPRETATIONS
    
    elif lookup_name in ["Hs", "D", "Hy", "Pd", "Mf", "Pa", "Pt", "Sc", "Ma", "Si"] or (scale_type == "CLINICAL"):
        interpretation_dict = CLINICAL_SCALES_INTERPRETATIONS
    
    elif lookup_name in ["ANX", "FRS", "OBS", "DEP", "HEA", "BIZ", "ANG", "CYN", "ASP", "TPA", "LSE", "SOD", "FAM", "WRK", "TRT"] or (scale_type == "CONTENT"):
        interpretation_dict = CONTENT_SCALES_INTERPRETATIONS
    
    elif lookup_name in ["AGGR", "PSYC", "DISC", "NEGE", "INTR"] or (scale_type == "PSY5"):
        interpretation_dict = PSY5_SCALES_INTERPRETATIONS
    
    elif lookup_name in ["D1", "D2", "D3", "D4", "D5", "Hy1", "Hy2", "Hy3", "Hy4", "Hy5", "Pd1", "Pd2", "Pd3", "Pd4", "Pd5", "Pa1", "Pa2", "Pa3", "Sc1", "Sc2", "Sc3", "Sc4", "Sc5", "Sc6", "Ma1", "Ma2", "Ma3", "Ma4"] or (scale_type == "HARRIS_LINGOES"):
        interpretation_dict = HARRIS_LINGOES_SUBSCALES_INTERPRETATIONS
    
    elif lookup_name in ["A", "R", "Es", "Do", "Re", "Mt", "GM", "GF", "PK", "PS", "MDS", "APS", "AAS", "MAC-R", "O-H"] or (scale_type == "SUPPLEMENTARY"):
        interpretation_dict = SUPPLEMENTARY_SCALES_INTERPRETATIONS
    
    else:
        # If we can't determine the scale type, try each dictionary in order
        if lookup_name in CLINICAL_SCALES_INTERPRETATIONS:
            interpretation_dict = CLINICAL_SCALES_INTERPRETATIONS
        elif lookup_name in VALIDITY_SCALES_INTERPRETATIONS:
            interpretation_dict = VALIDITY_SCALES_INTERPRETATIONS
        elif lookup_name in CONTENT_SCALES_INTERPRETATIONS:
            interpretation_dict = CONTENT_SCALES_INTERPRETATIONS
        elif lookup_name in PSY5_SCALES_INTERPRETATIONS:
            interpretation_dict = PSY5_SCALES_INTERPRETATIONS
        elif lookup_name in HARRIS_LINGOES_SUBSCALES_INTERPRETATIONS:
            interpretation_dict = HARRIS_LINGOES_SUBSCALES_INTERPRETATIONS
        elif lookup_name in SUPPLEMENTARY_SCALES_INTERPRETATIONS:
            interpretation_dict = SUPPLEMENTARY_SCALES_INTERPRETATIONS
        else:
            return f"Interpretation not found for scale: {scale_name}"
    
    # Try to get the scale from the appropriate dictionary
    if lookup_name in interpretation_dict:
        scale_dict = interpretation_dict[lookup_name]
        
        # Check if there are gender-specific interpretations
        if gender and isinstance(scale_dict, dict) and gender.lower() in [k.lower() for k in scale_dict.keys()]:
            # Use gender-specific interpretation
            gender_key = "male" if gender.lower() == "male" else "female"
            if gender_key in scale_dict:
                gender_dict = scale_dict[gender_key]
                
                # Find the appropriate range for the T-score
                if "ranges" in gender_dict:
                    for range_dict in gender_dict["ranges"]:
                        min_val, max_val = range_dict["range"]
                        if min_val <= t_score <= max_val:
                            return range_dict["interpretation"]
                    
                    # If no range is found, return a default message
                    return f"No interpretation found for T-score {t_score} in scale {scale_name} for {gender}"
                else:
                    # If no ranges, return the entire gender-specific dictionary or interpretation
                    return gender_dict.get("interpretation", str(gender_dict))
            else:
                # If gender key not found, fall back to non-gender-specific interpretation
                pass
        
        # Check if the scale has a "ranges" key (non-gender-specific)
        if "ranges" in scale_dict:
            # Find the appropriate range for the T-score
            for range_dict in scale_dict["ranges"]:
                min_val, max_val = range_dict["range"]
                if min_val <= t_score <= max_val:
                    return range_dict["interpretation"]
            
            # If no range is found, return a default message
            return f"No interpretation found for T-score {t_score} in scale {scale_name}"
        
        elif isinstance(scale_dict, str):
            # If the scale dict is just a string, return it
            return scale_dict
        
        else:
            # If the scale doesn't have a "ranges" key, return a default interpretation
            return scale_dict.get("interpretation", f"No structured interpretation available for {scale_name}")
    else:
        # If the scale is not found in the dictionary, return a default message
        return f"Interpretation not found for scale: {lookup_name}"

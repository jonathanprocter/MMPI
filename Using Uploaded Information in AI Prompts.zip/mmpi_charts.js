/**
 * MMPI-2 Charts Module
 * 
 * This module provides functions for generating MMPI-2 profile charts using Chart.js
 */

// Common chart configuration and utilities
const MMPI_CHARTS = {
    // Color scheme
    colors: {
        line: 'rgb(0, 0, 255)',
        clinicalThreshold: 'rgb(255, 0, 0)',
        grid: 'rgba(0, 0, 0, 0.1)',
        text: 'rgb(0, 0, 0)'
    },
    
    // Common chart options
    commonOptions: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                callbacks: {
                    title: function(tooltipItems) {
                        return tooltipItems[0].label;
                    },
                    label: function(context) {
                        return `T-Score: ${context.parsed.y}`;
                    }
                }
            }
        },
        scales: {
            y: {
                min: 30,
                max: 120,
                ticks: {
                    stepSize: 10
                },
                title: {
                    display: true,
                    text: 'T-Score',
                    font: {
                        weight: 'bold',
                        size: 14
                    }
                },
                grid: {
                    color: function(context) {
                        if (context.tick.value === 65 || context.tick.value === 50) {
                            return MMPI_CHARTS.colors.clinicalThreshold;
                        }
                        return MMPI_CHARTS.colors.grid;
                    },
                    lineWidth: function(context) {
                        if (context.tick.value === 65 || context.tick.value === 50) {
                            return 2;
                        }
                        return 1;
                    }
                }
            },
            x: {
                ticks: {
                    font: {
                        size: 12
                    }
                }
            }
        }
    },
    
    // Add T-score annotations above data points
    addTScoreAnnotations: function(chart) {
        const ctx = chart.ctx;
        ctx.font = '10px Arial';
        ctx.fillStyle = MMPI_CHARTS.colors.text;
        ctx.textAlign = 'center';
        
        chart.data.datasets.forEach((dataset, datasetIndex) => {
            const meta = chart.getDatasetMeta(datasetIndex);
            
            dataset.data.forEach((data, index) => {
                const position = meta.data[index].getCenterPoint();
                ctx.fillText(data, position.x, position.y - 10);
            });
        });
    }
};

/**
 * Generate Traditional MMPI-2 Profile Chart
 * 
 * @param {string} canvasId - ID of the canvas element
 * @param {Object} scores - Object containing clinical scale scores
 * @param {Object} clientInfo - Object containing client information
 */
function generateTraditionalProfileChart(canvasId, scores, clientInfo) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Define scale names and order
    const scaleNames = ['L', 'F', 'K', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
    
    // Extract scores in correct order
    const scaleScores = scaleNames.map(scale => scores[scale] || 50);
    
    // Create chart
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: scaleNames,
            datasets: [{
                label: 'T-Score',
                data: scaleScores,
                borderColor: MMPI_CHARTS.colors.line,
                backgroundColor: 'rgba(0, 0, 255, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: MMPI_CHARTS.colors.line,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: false,
                tension: 0
            }]
        },
        options: {
            ...MMPI_CHARTS.commonOptions,
            plugins: {
                ...MMPI_CHARTS.commonOptions.plugins,
                title: {
                    display: true,
                    text: `MMPI-2 Traditional Profile: ${clientInfo.name} (${clientInfo.sex === 'female' ? 'Female' : 'Male'})`,
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                }
            },
            animation: {
                onComplete: function() {
                    MMPI_CHARTS.addTScoreAnnotations(this);
                }
            }
        }
    });
    
    return chart;
}

/**
 * Generate Content Scales Chart
 * 
 * @param {string} canvasId - ID of the canvas element
 * @param {Object} scores - Object containing content scale scores
 * @param {Object} clientInfo - Object containing client information
 */
function generateContentScalesChart(canvasId, scores, clientInfo) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Define scale names and order
    const scaleNames = ['ANX', 'FRS', 'OBS', 'DEP', 'HEA', 'BIZ', 'ANG', 'CYN', 'ASP', 'TPA', 'LSE', 'SOD', 'FAM', 'WRK', 'TRT'];
    
    // Extract scores in correct order
    const scaleScores = scaleNames.map(scale => scores[scale] || 50);
    
    // Create chart
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: scaleNames,
            datasets: [{
                label: 'T-Score',
                data: scaleScores,
                borderColor: MMPI_CHARTS.colors.line,
                backgroundColor: 'rgba(0, 0, 255, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: MMPI_CHARTS.colors.line,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: false,
                tension: 0
            }]
        },
        options: {
            ...MMPI_CHARTS.commonOptions,
            plugins: {
                ...MMPI_CHARTS.commonOptions.plugins,
                title: {
                    display: true,
                    text: `MMPI-2 Content Scales: ${clientInfo.name} (${clientInfo.sex === 'female' ? 'Female' : 'Male'})`,
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                }
            },
            animation: {
                onComplete: function() {
                    MMPI_CHARTS.addTScoreAnnotations(this);
                }
            }
        }
    });
    
    return chart;
}

/**
 * Generate RC Scales Chart
 * 
 * @param {string} canvasId - ID of the canvas element
 * @param {Object} scores - Object containing RC scale scores
 * @param {Object} clientInfo - Object containing client information
 */
function generateRCScalesChart(canvasId, scores, clientInfo) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Define scale names and order
    const scaleNames = ['RCd', 'RC1', 'RC2', 'RC3', 'RC4', 'RC6', 'RC7', 'RC8', 'RC9'];
    const fullScaleNames = [
        'RCd: Demoralization', 
        'RC1: Somatic Complaints', 
        'RC2: Low Positive Emotions', 
        'RC3: Cynicism', 
        'RC4: Antisocial Behavior', 
        'RC6: Ideas of Persecution', 
        'RC7: Dysfunctional Negative Emotions', 
        'RC8: Aberrant Experiences', 
        'RC9: Hypomanic Activation'
    ];
    
    // Extract scores in correct order
    const scaleScores = scaleNames.map(scale => scores[scale] || 50);
    
    // Create chart
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: scaleNames,
            datasets: [{
                label: 'T-Score',
                data: scaleScores,
                borderColor: MMPI_CHARTS.colors.line,
                backgroundColor: 'rgba(0, 0, 255, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: MMPI_CHARTS.colors.line,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: false,
                tension: 0
            }]
        },
        options: {
            ...MMPI_CHARTS.commonOptions,
            plugins: {
                ...MMPI_CHARTS.commonOptions.plugins,
                title: {
                    display: true,
                    text: `MMPI-2 Restructured Clinical Scales: ${clientInfo.name} (${clientInfo.sex === 'female' ? 'Female' : 'Male'})`,
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                tooltip: {
                    callbacks: {
                        title: function(tooltipItems) {
                            const index = tooltipItems[0].dataIndex;
                            return fullScaleNames[index];
                        },
                        label: function(context) {
                            return `T-Score: ${context.parsed.y}`;
                        }
                    }
                }
            },
            animation: {
                onComplete: function() {
                    MMPI_CHARTS.addTScoreAnnotations(this);
                }
            }
        }
    });
    
    return chart;
}

/**
 * Generate PSY-5 Scales Chart
 * 
 * @param {string} canvasId - ID of the canvas element
 * @param {Object} scores - Object containing PSY-5 scale scores
 * @param {Object} clientInfo - Object containing client information
 */
function generatePSY5ScalesChart(canvasId, scores, clientInfo) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Define scale names and order
    const scaleNames = ['AGGR', 'PSYC', 'DISC', 'NEGE', 'INTR'];
    
    // Extract scores in correct order
    const scaleScores = scaleNames.map(scale => scores[scale] || 50);
    
    // Create chart
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: scaleNames,
            datasets: [{
                label: 'T-Score',
                data: scaleScores,
                borderColor: MMPI_CHARTS.colors.line,
                backgroundColor: 'rgba(0, 0, 255, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: MMPI_CHARTS.colors.line,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: false,
                tension: 0
            }]
        },
        options: {
            ...MMPI_CHARTS.commonOptions,
            plugins: {
                ...MMPI_CHARTS.commonOptions.plugins,
                title: {
                    display: true,
                    text: `MMPI-2 PSY-5 Scales: ${clientInfo.name} (${clientInfo.sex === 'female' ? 'Female' : 'Male'})`,
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                }
            },
            animation: {
                onComplete: function() {
                    MMPI_CHARTS.addTScoreAnnotations(this);
                }
            }
        }
    });
    
    return chart;
}

/**
 * Generate Supplementary Scales Chart
 * 
 * @param {string} canvasId - ID of the canvas element
 * @param {Object} scores - Object containing supplementary scale scores
 * @param {Object} clientInfo - Object containing client information
 */
function generateSupplementaryScalesChart(canvasId, scores, clientInfo) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Define scale names and order
    const scaleNames = ['A', 'R', 'Es', 'Do', 'Re', 'Mt', 'PK', 'MDS', 'Ho', 'O-H', 'MAC-R', 'APS', 'GM', 'GF'];
    
    // Extract scores in correct order
    const scaleScores = scaleNames.map(scale => scores[scale] || 50);
    
    // Create chart
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: scaleNames,
            datasets: [{
                label: 'T-Score',
                data: scaleScores,
                borderColor: MMPI_CHARTS.colors.line,
                backgroundColor: 'rgba(0, 0, 255, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: MMPI_CHARTS.colors.line,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: false,
                tension: 0
            }]
        },
        options: {
            ...MMPI_CHARTS.commonOptions,
            plugins: {
                ...MMPI_CHARTS.commonOptions.plugins,
                title: {
                    display: true,
                    text: `MMPI-2 Supplementary Scales: ${clientInfo.name} (${clientInfo.sex === 'female' ? 'Female' : 'Male'})`,
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                }
            },
            animation: {
                onComplete: function() {
                    MMPI_CHARTS.addTScoreAnnotations(this);
                }
            }
        }
    });
    
    return chart;
}

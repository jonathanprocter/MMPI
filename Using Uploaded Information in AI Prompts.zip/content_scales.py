"""
Content Scales Interpretations for MMPI-2.

This module provides detailed interpretations for MMPI-2 Content Scales
based on T-score ranges and gender.
"""

# Content Scales Interpretations Dictionary
CONTENT_SCALES_INTERPRETATIONS = {
    "ANX": {
        "female": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This female reports minimal anxiety symptoms. She describes herself as generally calm and able to manage stress effectively. She denies significant worry, tension, or physiological manifestations of anxiety. Her functioning across various domains remains unimpaired by anxiety-related concerns."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This female reports moderate anxiety symptoms that create noticeable distress but allow continued functioning. She describes periodic experiences of worry, tension, and physiological arousal that exceed normal stress responses. While she maintains some ability to manage these symptoms, they require increased effort and attention."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports significant anxiety symptoms that substantially impact her daily functioning. She describes persistent worry, tension, and physiological arousal that interfere with concentration, decision-making, and performance. Her anxiety symptoms may include restlessness, muscle tension, autonomic hyperactivity, vigilance, and apprehension that create considerable subjective suffering."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This male reports minimal anxiety symptoms. He describes himself as generally calm and able to manage stress effectively. He denies significant worry, tension, or physiological manifestations of anxiety. His functioning across various domains remains unimpaired by anxiety-related concerns."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This male reports moderate anxiety symptoms that create noticeable distress but allow continued functioning. He describes periodic experiences of worry, tension, and physiological arousal that exceed normal stress responses. While he maintains some ability to manage these symptoms, they require increased effort and attention."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports significant anxiety symptoms that substantially impact his daily functioning. He describes persistent worry, tension, and physiological arousal that interfere with concentration, decision-making, and performance. His anxiety symptoms may include restlessness, muscle tension, autonomic hyperactivity, vigilance, and apprehension that create considerable subjective suffering."
                }
            ]
        }
    },
    "FRS": {
        "female": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This female reports minimal specific fears. She denies significant anxiety responses to common phobic stimuli such as heights, enclosed spaces, or animals. She describes herself as generally comfortable in situations that often provoke fear in others. Her daily activities remain unimpaired by avoidance of feared situations or objects."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This female reports moderate specific fears that create noticeable distress but allow continued functioning. She describes anxiety responses to certain phobic stimuli that exceed normal caution or concern. While she maintains some ability to confront feared situations when necessary, doing so requires increased effort and causes significant discomfort."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports significant specific fears that substantially impact her daily functioning. She describes intense anxiety responses to multiple phobic stimuli that lead to consistent avoidance behaviors. Her fears may include situations (e.g., heights, enclosed spaces), natural environment (e.g., storms, water), animals, blood/injury, or other specific objects or circumstances that significantly restrict her activities and choices."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This male reports minimal specific fears. He denies significant anxiety responses to common phobic stimuli such as heights, enclosed spaces, or animals. He describes himself as generally comfortable in situations that often provoke fear in others. His daily activities remain unimpaired by avoidance of feared situations or objects."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This male reports moderate specific fears that create noticeable distress but allow continued functioning. He describes anxiety responses to certain phobic stimuli that exceed normal caution or concern. While he maintains some ability to confront feared situations when necessary, doing so requires increased effort and causes significant discomfort."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports significant specific fears that substantially impact his daily functioning. He describes intense anxiety responses to multiple phobic stimuli that lead to consistent avoidance behaviors. His fears may include situations (e.g., heights, enclosed spaces), natural environment (e.g., storms, water), animals, blood/injury, or other specific objects or circumstances that significantly restrict his activities and choices."
                }
            ]
        }
    },
    "OBS": {
        "female": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This female reports minimal obsessive-compulsive symptoms. She denies significant intrusive thoughts, ritualistic behaviors, or excessive concerns about order and control. Her decision-making remains flexible and efficient, without undue rumination or perfectionism. Her daily activities proceed without significant interference from obsessive-compulsive tendencies."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This female reports moderate obsessive-compulsive symptoms that create noticeable distress but allow continued functioning. She describes some intrusive thoughts, ritualistic behaviors, or excessive concerns about order and control. Her decision-making shows increasing rigidity and rumination, with growing perfectionism that delays task completion. Her daily activities show some interference from obsessive-compulsive tendencies."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports significant obsessive-compulsive symptoms that substantially impact her daily functioning. She describes persistent intrusive thoughts, ritualistic behaviors, or excessive concerns about order and control. Her decision-making shows marked rigidity and rumination, with pronounced perfectionism that significantly delays or prevents task completion. Her daily activities show substantial interference from obsessive-compulsive tendencies, with considerable time spent on rituals or obsessional thinking."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This male reports minimal obsessive-compulsive symptoms. He denies significant intrusive thoughts, ritualistic behaviors, or excessive concerns about order and control. His decision-making remains flexible and efficient, without undue rumination or perfectionism. His daily activities proceed without significant interference from obsessive-compulsive tendencies."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This male reports moderate obsessive-compulsive symptoms that create noticeable distress but allow continued functioning. He describes some intrusive thoughts, ritualistic behaviors, or excessive concerns about order and control. His decision-making shows increasing rigidity and rumination, with growing perfectionism that delays task completion. His daily activities show some interference from obsessive-compulsive tendencies."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports significant obsessive-compulsive symptoms that substantially impact his daily functioning. He describes persistent intrusive thoughts, ritualistic behaviors, or excessive concerns about order and control. His decision-making shows marked rigidity and rumination, with pronounced perfectionism that significantly delays or prevents task completion. His daily activities show substantial interference from obsessive-compulsive tendencies, with considerable time spent on rituals or obsessional thinking."
                }
            ]
        }
    },
    "DEP": {
        "female": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This female reports minimal depressive symptoms. She describes her mood as generally positive or neutral, with normal fluctuations in response to life events. She maintains interest and pleasure in activities, adequate energy, and positive views of herself and her future. Her functioning across various domains remains unimpaired by depressive symptoms."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This female reports moderate depressive symptoms that create noticeable distress but allow continued functioning. She describes periodic experiences of sadness, anhedonia, fatigue, or negative cognitions that exceed normal mood fluctuations. While she maintains some ability to experience pleasure and hope, these capacities are diminished and require increased effort."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports significant depressive symptoms that substantially impact her daily functioning. She describes persistent sadness, anhedonia, fatigue, and negative cognitions that interfere with motivation, concentration, and performance. Her self-perception is characterized by worthlessness, hopelessness, and excessive guilt. She may acknowledge passive death wishes or suicidal ideation without specific intent or plan."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This male reports minimal depressive symptoms. He describes his mood as generally positive or neutral, with normal fluctuations in response to life events. He maintains interest and pleasure in activities, adequate energy, and positive views of himself and his future. His functioning across various domains remains unimpaired by depressive symptoms."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This male reports moderate depressive symptoms that create noticeable distress but allow continued functioning. He describes periodic experiences of sadness, anhedonia, fatigue, or negative cognitions that exceed normal mood fluctuations. While he maintains some ability to experience pleasure and hope, these capacities are diminished and require increased effort."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports significant depressive symptoms that substantially impact his daily functioning. He describes persistent sadness, anhedonia, fatigue, and negative cognitions that interfere with motivation, concentration, and performance. His self-perception is characterized by worthlessness, hopelessness, and excessive guilt. He may acknowledge passive death wishes or suicidal ideation without specific intent or plan."
                }
            ]
        }
    },
    "HEA": {
        "female": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This female reports minimal health concerns. She describes her physical health as generally good, with normal responses to occasional illness or discomfort. She maintains a balanced perspective on bodily sensations and medical symptoms, without excessive worry or preoccupation. Her functioning across various domains remains unimpaired by health-related concerns."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This female reports moderate health concerns that create noticeable distress but allow continued functioning. She describes increased attention to bodily sensations and medical symptoms, with some tendency to interpret ambiguous physical experiences negatively. While she maintains some perspective on her health status, she shows growing preoccupation with potential illness or disability."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports significant health concerns that substantially impact her daily functioning. She describes persistent preoccupation with bodily sensations and medical symptoms, with pronounced tendency to interpret ambiguous physical experiences as evidence of serious illness. Her attention is dominated by health-related worries, leading to frequent medical consultations, excessive self-monitoring, and restriction of activities due to perceived physical limitations."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 59],
                    "interpretation": "This male reports minimal health concerns. He describes his physical health as generally good, with normal responses to occasional illness or discomfort. He maintains a balanced perspective on bodily sensations and medical symptoms, without excessive worry or preoccupation. His functioning across various domains remains unimpaired by health-related concerns."
                },
                {
                    "range": [60, 64],
                    "interpretation": "This male reports moderate health concerns that create noticeable distress but allow continued functioning. He describes increased attention to bodily sensations and medical symptoms, with some tendency to interpret ambiguous physical experiences negatively. While he maintains some perspective on his health status, he shows growing preoccupation with potential illness or disability."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports significant health concerns that substantially impact his daily functioning. He describes persistent preoccupation with bodily sensations and medical symptoms, with pronounced tendency to interpret ambiguous physical experiences as evidence of serious illness. His attention is dominated by health-related worries, leading to frequent medical consu
(Content truncated due to size limit. Use line ranges to read in chunks)
        "date_tested": datetime.now().strftime("%Y-%m-%d"),
        "education": "Bachelor's Degree",
        "marital_status": "Divorced",
        "referral_source": "Self-referred",
        "presenting_concerns": "Anxiety, depression, relationship difficulties, physical complaints"
    }
    
    # Validity Scales (T-scores)
    validity_scales = {
        "VRIN": 58,
        "TRIN": 57,
        "F": 75,
        "Fb": 78,
        "Fp": 65,
        "L": 45,
        "K": 40,
        "S": 38
    }
    
    # Clinical Scales (T-scores)
    clinical_scales = {
        "1": 78,  # Hs (Hypochondriasis)
        "2": 82,  # D (Depression)
        "3": 70,  # Hy (Hysteria)
        "4": 68,  # Pd (Psychopathic Deviate)
        "5": 55,  # Mf (Masculinity-Femininity)
        "6": 72,  # Pa (Paranoia)
        "7": 85,  # Pt (Psychasthenia)
        "8": 76,  # Sc (Schizophrenia)
        "9": 45,  # Ma (Hypomania)
        "0": 70   # Si (Social Introversion)
    }
    
    # Harris-Lingoes Subscales (T-scores)
    harris_lingoes_subscales = {
        "D1": 80,  # Subjective Depression
        "D2": 75,  # Psychomotor Retardation
        "D3": 78,  # Physical Malfunctioning
        "D4": 72,  # Mental Dullness
        "D5": 68,  # Brooding
        "Hy1": 45, # Denial of Social Anxiety
        "Hy2": 72, # Need for Affection
        "Hy3": 78, # Lassitude-Malaise
        "Hy4": 74, # Somatic Complaints
        "Hy5": 65, # Inhibition of Aggression
        "Pd1": 70, # Familial Discord
        "Pd2": 65, # Authority Problems
        "Pd3": 72, # Social Imperturbability
        "Pd4": 68, # Social Alienation
        "Pd5": 72, # Self-Alienation
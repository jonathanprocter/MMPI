"""
Harris-Lingoes Subscales Interpretations for MMPI-2.

This module provides detailed interpretations for MMPI-2 Harris-Lingoes Subscales
based on T-score ranges and gender.
"""

# Harris-Lingoes Subscales Interpretations Dictionary
HARRIS_LINGOES_SUBSCALES_INTERPRETATIONS = {
    "D1": {
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female reports minimal subjective depression. She denies significant feelings of sadness, hopelessness, or worthlessness. Her mood is generally stable and appropriate to circumstances. She maintains interest and pleasure in activities and relationships. Her outlook on the future is reasonably optimistic."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female reports moderate subjective depression that creates noticeable distress but allows continued functioning. She describes periodic feelings of sadness, discouragement, and self-doubt that exceed normal mood fluctuations. While she maintains some capacity for positive emotions, these experiences are diminished in frequency and intensity."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports profound subjective depression that significantly impacts her daily functioning. She describes persistent feelings of sadness, hopelessness, and worthlessness that color all aspects of her experience. Her emotional pain is experienced as overwhelming and interminable. She reports minimal or no capacity for positive emotions such as joy, pleasure, or enthusiasm."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male reports minimal subjective depression. He denies significant feelings of sadness, hopelessness, or worthlessness. His mood is generally stable and appropriate to circumstances. He maintains interest and pleasure in activities and relationships. His outlook on the future is reasonably optimistic."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male reports moderate subjective depression that creates noticeable distress but allows continued functioning. He describes periodic feelings of sadness, discouragement, and self-doubt that exceed normal mood fluctuations. While he maintains some capacity for positive emotions, these experiences are diminished in frequency and intensity."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports profound subjective depression that significantly impacts his daily functioning. He describes persistent feelings of sadness, hopelessness, and worthlessness that color all aspects of his experience. His emotional pain is experienced as overwhelming and interminable. He reports minimal or no capacity for positive emotions such as joy, pleasure, or enthusiasm."
                }
            ]
        }
    },
    "D2": {
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female reports normal energy and activity levels. She maintains adequate motivation and drive for daily tasks and responsibilities. Her physical movements and speech patterns show normal pace and animation. She denies significant fatigue beyond appropriate responses to exertion or stress."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female reports moderate psychomotor retardation that creates noticeable limitations but allows essential functioning. She describes diminished energy and motivation that require increased effort to complete routine tasks. Her physical movements and speech may show subtle slowing. She reports increased fatigue that is not fully relieved by rest."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports profound psychomotor retardation that significantly impacts her daily functioning. She describes extreme fatigue and lack of energy that make even simple tasks feel overwhelming. Her physical movements and speech are noticeably slowed. She reports spending increased time in bed or inactive without feeling restored."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male reports normal energy and activity levels. He maintains adequate motivation and drive for daily tasks and responsibilities. His physical movements and speech patterns show normal pace and animation. He denies significant fatigue beyond appropriate responses to exertion or stress."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male reports moderate psychomotor retardation that creates noticeable limitations but allows essential functioning. He describes diminished energy and motivation that require increased effort to complete routine tasks. His physical movements and speech may show subtle slowing. He reports increased fatigue that is not fully relieved by rest."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports profound psychomotor retardation that significantly impacts his daily functioning. He describes extreme fatigue and lack of energy that make even simple tasks feel overwhelming. His physical movements and speech are noticeably slowed. He reports spending increased time in bed or inactive without feeling restored."
                }
            ]
        }
    },
    "D3": {
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female reports minimal physical complaints. She experiences normal bodily functioning with occasional and appropriate responses to illness or injury. Physical symptoms do not significantly impact her daily activities or create ongoing concern."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female reports moderate physical complaints that create noticeable distress but do not severely restrict activities. She experiences periodic somatic symptoms that exceed typical responses to normal stressors. These physical manifestations may include headaches, gastrointestinal distress, or musculoskeletal pain without clear medical explanation."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports significant physical complaints that substantially impact her functioning. She describes multiple somatic symptoms that create considerable subjective suffering. These physical manifestations may include chronic pain, gastrointestinal distress, neurological symptoms, or general malaise without adequate medical explanation."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male reports minimal physical complaints. He experiences normal bodily functioning with occasional and appropriate responses to illness or injury. Physical symptoms do not significantly impact his daily activities or create ongoing concern."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male reports moderate physical complaints that create noticeable distress but do not severely restrict activities. He experiences periodic somatic symptoms that exceed typical responses to normal stressors. These physical manifestations may include headaches, gastrointestinal distress, or musculoskeletal pain without clear medical explanation."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports significant physical complaints that substantially impact his functioning. He describes multiple somatic symptoms that create considerable subjective suffering. These physical manifestations may include chronic pain, gastrointestinal distress, neurological symptoms, or general malaise without adequate medical explanation."
                }
            ]
        }
    },
    "D4": {
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female reports normal cognitive functioning. She maintains adequate concentration, memory, and decision-making abilities. Her thinking remains clear and efficient across various contexts and demands. She can process information at an appropriate pace without significant mental fatigue."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female reports moderate cognitive difficulties that create noticeable impairment but allow essential functioning. She describes problems with concentration, memory, and decision-making that exceed normal variations. Her thinking becomes less efficient, requiring more effort and time to process information. She reports increased mental fatigue with cognitive demands."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports profound cognitive difficulties that significantly impact her daily functioning. She describes severe problems with concentration, memory, and decision-making that compromise her ability to manage routine tasks. Her thinking feels clouded and inefficient across contexts. She reports extreme mental fatigue with even minimal cognitive demands."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male reports normal cognitive functioning. He maintains adequate concentration, memory, and decision-making abilities. His thinking remains clear and efficient across various contexts and demands. He can process information at an appropriate pace without significant mental fatigue."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male reports moderate cognitive difficulties that create noticeable impairment but allow essential functioning. He describes problems with concentration, memory, and decision-making that exceed normal variations. His thinking becomes less efficient, requiring more effort and time to process information. He reports increased mental fatigue with cognitive demands."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports profound cognitive difficulties that significantly impact his daily functioning. He describes severe problems with concentration, memory, and decision-making that compromise his ability to manage routine tasks. His thinking feels clouded and inefficient across contexts. He reports extreme mental fatigue with even minimal cognitive demands."
                }
            ]
        }
    },
    "D5": {
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female reports minimal rumination or worry. Her thought patterns remain generally positive or neutral without persistent negative focus. When concerns arise, she can typically redirect her attention to more constructive or pleasant topics. She maintains perspective on problems without catastrophizing."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female reports moderate rumination that creates noticeable distress but allows continued functioning. She describes increased preoccupation with worries, regrets, or perceived shortcomings that is difficult to control. Her thought patterns show a negative bias that requires conscious effort to redirect. She has some difficulty maintaining perspective on problems."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female reports profound rumination that significantly impacts her mental well-being. She describes persistent preoccupation with worries, regrets, and perceived failures that she cannot control despite recognizing their unproductive nature. Her thought patterns are dominated by negative content with minimal ability to redirect to neutral or positive topics."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This male reports minimal rumination or worry. His thought patterns remain generally positive or neutral without persistent negative focus. When concerns arise, he can typically redirect his attention to more constructive or pleasant topics. He maintains perspective on problems without catastrophizing."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This male reports moderate rumination that creates noticeable distress but allows continued functioning. He describes increased preoccupation with worries, regrets, or perceived shortcomings that is difficult to control. His thought patterns show a negative bias that requires conscious effort to redirect. He has some difficulty maintaining perspective on problems."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male reports profound rumination that significantly impacts his mental well-being. He describes persistent preoccupation with worries, regrets, and perceived failures that he cannot control despite recognizing their unproductive nature. His thought patterns are dominated by negative content with minimal ability to redirect to neutral or positive topics."
                }
            ]
        }
    },
    "Hy1": {
        "female": {
            "ranges": [
                {
                    "range": [0, 50],
                    "interpretation": "This female acknowledges normal social anxiety. She reports appropriate concern about how others perceive her without excessive self-consciousness. In social situations, she experiences manageable levels of discomfort that do not significantly interfere with engagement. She can acknowledge interpersonal difficulties when they occur rather than denying their existence."
                },
                {
                    "range": [51, 64],
                    "interpretation": "This female shows moderate denial of social anxiety that creates some interpersonal blind spots. She minimizes or disavows normal social discomfort even in challenging situations. She presents herself as exceptionally comfortable and confident in social contexts despite behavioral evidence suggesting otherwise. She has difficulty acknowledging interpersonal problems when they occur."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female shows pronounced denial of social anxiety that significantly impacts her self-awareness and relationships. She strongly disavows any social discomfort or self-consciousness despite objective evidence to the contrary. She presents an exaggerated facade of social ease and interpersona
(Content truncated due to size limit. Use line ranges to read in chunks)
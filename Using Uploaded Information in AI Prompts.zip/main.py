"""
MMPI-2 Assessment Platform - Main Application Entry Point
This module provides the Flask application entry point for deployment.
"""

from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, jsonify
import os
import uuid
import json
from datetime import datetime

# Create Flask application
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'mmpi2_assessment_platform_secret_key')
app.config['REPORT_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'reports')

# Ensure report directory exists
if not os.path.exists(app.config['REPORT_FOLDER']):
    os.makedirs(app.config['REPORT_FOLDER'])

@app.route('/')
def index():
    """Home page."""
    return render_template('index.html')

@app.route('/client_info', methods=['GET', 'POST'])
def client_info():
    """Client information form."""
    if request.method == 'POST':
        # Store client info in session
        session['client_info'] = {
            'name': request.form.get('name'),
            'age': request.form.get('age'),
            'sex': request.form.get('sex'),
            'date': request.form.get('date') or datetime.now().strftime('%Y-%m-%d'),
            'referral_source': request.form.get('referral_source'),
            'reason_for_referral': request.form.get('reason_for_referral')
        }
        return redirect(url_for('score_entry'))
    return render_template('client_info.html')

@app.route('/score_entry', methods=['GET', 'POST'])
def score_entry():
    """Score entry form."""
    if request.method == 'POST':
        # Store scores in session
        session['scores'] = {
            'validity_scales': {
                'L': int(request.form.get('L', 50)),
                'F': int(request.form.get('F', 50)),
                'K': int(request.form.get('K', 50)),
                'VRIN': int(request.form.get('VRIN', 50)),
                'TRIN': int(request.form.get('TRIN', 50)),
                'Fb': int(request.form.get('Fb', 50)),
                'Fp': int(request.form.get('Fp', 50)),
                'FBS': int(request.form.get('FBS', 50)),
                'S': int(request.form.get('S', 50))
            },
            'clinical_scales': {
                'L': int(request.form.get('L', 50)),
                'F': int(request.form.get('F', 50)),
                'K': int(request.form.get('K', 50)),
                '1': int(request.form.get('1', 50)),
                '2': int(request.form.get('2', 50)),
                '3': int(request.form.get('3', 50)),
                '4': int(request.form.get('4', 50)),
                '5': int(request.form.get('5', 50)),
                '6': int(request.form.get('6', 50)),
                '7': int(request.form.get('7', 50)),
                '8': int(request.form.get('8', 50)),
                '9': int(request.form.get('9', 50)),
                '0': int(request.form.get('0', 50))
            },
            'content_scales': {
                'ANX': int(request.form.get('ANX', 50)),
                'FRS': int(request.form.get('FRS', 50)),
                'OBS': int(request.form.get('OBS', 50)),
                'DEP': int(request.form.get('DEP', 50)),
                'HEA': int(request.form.get('HEA', 50)),
                'BIZ': int(request.form.get('BIZ', 50)),
                'ANG': int(request.form.get('ANG', 50)),
                'CYN': int(request.form.get('CYN', 50)),
                'ASP': int(request.form.get('ASP', 50)),
                'TPA': int(request.form.get('TPA', 50)),
                'LSE': int(request.form.get('LSE', 50)),
                'SOD': int(request.form.get('SOD', 50)),
                'FAM': int(request.form.get('FAM', 50)),
                'WRK': int(request.form.get('WRK', 50)),
                'TRT': int(request.form.get('TRT', 50))
            },
            'rc_scales': {
                'RCd': int(request.form.get('RCd', 50)),
                'RC1': int(request.form.get('RC1', 50)),
                'RC2': int(request.form.get('RC2', 50)),
                'RC3': int(request.form.get('RC3', 50)),
                'RC4': int(request.form.get('RC4', 50)),
                'RC6': int(request.form.get('RC6', 50)),
                'RC7': int(request.form.get('RC7', 50)),
                'RC8': int(request.form.get('RC8', 50)),
                'RC9': int(request.form.get('RC9', 50))
            },
            'psy5_scales': {
                'AGGR': int(request.form.get('AGGR', 50)),
                'PSYC': int(request.form.get('PSYC', 50)),
                'DISC': int(request.form.get('DISC', 50)),
                'NEGE': int(request.form.get('NEGE', 50)),
                'INTR': int(request.form.get('INTR', 50))
            },
            'supplementary_scales': {
                'A': int(request.form.get('A', 50)),
                'R': int(request.form.get('R', 50)),
                'Es': int(request.form.get('Es', 50)),
                'Do': int(request.form.get('Do', 50)),
                'Re': int(request.form.get('Re', 50)),
                'Mt': int(request.form.get('Mt', 50)),
                'PK': int(request.form.get('PK', 50)),
                'MDS': int(request.form.get('MDS', 50)),
                'Ho': int(request.form.get('Ho', 50)),
                'O-H': int(request.form.get('O-H', 50)),
                'MAC-R': int(request.form.get('MAC-R', 50)),
                'APS': int(request.form.get('APS', 50)),
                'GM': int(request.form.get('GM', 50)),
                'GF': int(request.form.get('GF', 50))
            },
            'harris_lingoes_subscales': {
                'D1': int(request.form.get('D1', 50)),
                'D2': int(request.form.get('D2', 50)),
                'D3': int(request.form.get('D3', 50)),
                'D4': int(request.form.get('D4', 50)),
                'D5': int(request.form.get('D5', 50)),
                'Hy1': int(request.form.get('Hy1', 50)),
                'Hy2': int(request.form.get('Hy2', 50)),
                'Hy3': int(request.form.get('Hy3', 50)),
                'Hy4': int(request.form.get('Hy4', 50)),
                'Hy5': int(request.form.get('Hy5', 50)),
                'Pd1': int(request.form.get('Pd1', 50)),
                'Pd2': int(request.form.get('Pd2', 50)),
                'Pd3': int(request.form.get('Pd3', 50)),
                'Pd4': int(request.form.get('Pd4', 50)),
                'Pd5': int(request.form.get('Pd5', 50)),
                'Pa1': int(request.form.get('Pa1', 50)),
                'Pa2': int(request.form.get('Pa2', 50)),
                'Pa3': int(request.form.get('Pa3', 50)),
                'Sc1': int(request.form.get('Sc1', 50)),
                'Sc2': int(request.form.get('Sc2', 50)),
                'Sc3': int(request.form.get('Sc3', 50)),
                'Sc4': int(request.form.get('Sc4', 50)),
                'Sc5': int(request.form.get('Sc5', 50)),
                'Sc6': int(request.form.get('Sc6', 50)),
                'Ma1': int(request.form.get('Ma1', 50)),
                'Ma2': int(request.form.get('Ma2', 50)),
                'Ma3': int(request.form.get('Ma3', 50)),
                'Ma4': int(request.form.get('Ma4', 50))
            }
        }
        return redirect(url_for('generate_report'))
    return render_template('score_entry.html')

@app.route('/generate_report', methods=['GET'])
def generate_report():
    """Generate comprehensive report."""
    if 'client_info' not in session or 'scores' not in session:
        return redirect(url_for('index'))
    
    # Create unique report ID and directory
    report_id = str(uuid.uuid4())
    report_dir = os.path.join(app.config['REPORT_FOLDER'], report_id)
    os.makedirs(report_dir, exist_ok=True)
    
    # Save client info and scores as JSON
    with open(os.path.join(report_dir, 'client_info.json'), 'w') as f:
        json.dump(session['client_info'], f, indent=4)
    
    with open(os.path.join(report_dir, 'scores.json'), 'w') as f:
        json.dump(session['scores'], f, indent=4)
    
    # Generate text-based report
    from src.reporting.comprehensive_report_generator import ComprehensiveReportGenerator
    report_generator = ComprehensiveReportGenerator(report_dir)
    
    # Generate text report
    text_report = report_generator.generate_text_report(session['client_info'], session['scores'])
    with open(os.path.join(report_dir, 'comprehensive_report.txt'), 'w') as f:
        f.write(text_report)
    
    # Generate JSON report
    json_report = report_generator.generate_json_report(session['client_info'], session['scores'])
    with open(os.path.join(report_dir, 'comprehensive_report.json'), 'w') as f:
        json.dump(json_report, f, indent=4)
    
    # Generate HTML report
    html_report = report_generator.generate_html_report(session['client_info'], session['scores'])
    with open(os.path.join(report_dir, 'comprehensive_report.html'), 'w') as f:
        f.write(html_report)
    
    # Redirect to view report page
    return redirect(url_for('view_report', report_id=report_id))

@app.route('/view_report/<report_id>', methods=['GET'])
def view_report(report_id):
    """View generated report."""
    report_dir = os.path.join(app.config['REPORT_FOLDER'], report_id)
    
    # Check if report directory exists
    if not os.path.exists(report_dir):
        return redirect(url_for('index'))
    
    # Load client info and scores
    with open(os.path.join(report_dir, 'client_info.json'), 'r') as f:
        client_info = json.load(f)
    
    with open(os.path.join(report_dir, 'scores.json'), 'r') as f:
        scores = json.load(f)
    
    # Check if report files exist
    html_path = os.path.join(report_dir, 'comprehensive_report.html')
    
    # Check if files exist
    html_exists = os.path.exists(html_path)
    
    # Use the interactive report template with Chart.js
    return render_template('view_report_interactive.html', 
                          report_id=report_id,
                          html_exists=html_exists,
                          client_info=client_info,
                          scores=scores)

@app.route('/reports/<report_id>/<filename>', methods=['GET'])
def report_file(report_id, filename):
    """Serve report files."""
    report_dir = os.path.join(app.config['REPORT_FOLDER'], report_id)
    return send_from_directory(report_dir, filename)

@app.route('/sample_data', methods=['GET'])
def sample_data():
    """Load sample data for demonstration."""
    # Sample client info
    session['client_info'] = {
        'name': 'John Smith',
        'age': '35',
        'sex': 'male',
        'date': datetime.now().strftime('%Y-%m-%d'),
        'referral_source': 'Dr. Jane Doe',
        'reason_for_referral': 'Diagnostic clarification and treatment planning'
    }
    
    # Sample scores based on provided screenshots
    session['scores'] = {
        'validity_scales': {
            'L': 45, 'F': 51, 'K': 51, 'VRIN': 73, 'TRIN': 57, 'Fb': 51, 'Fp': 56, 'FBS': 43, 'S': 34
        },
        'clinical_scales': {
            'L': 45, 'F': 51, 'K': 51, '1': 51, '2': 51, '3': 51, '4': 68, '5': 62, '6': 53, '7': 44, '8': 56, '9': 56, '0': 44
        },
        'content_scales': {
            'ANX': 62, 'FRS': 67, 'OBS': 53, 'DEP': 55, 'HEA': 56, 'BIZ': 57, 'ANG': 63, 'CYN': 56, 'ASP': 53, 'TPA': 60, 'LSE': 53, 'SOD': 49, 'FAM': 66, 'WRK': 61, 'TRT': 56
        },
        'rc_scales': {
            'RCd': 54, 'RC1': 63, 'RC2': 46, 'RC3': 56, 'RC4': 71, 'RC6': 62, 'RC7': 52, 'RC8': 59, 'RC9': 61
        },
        'psy5_scales': {
            'AGGR': 74, 'PSYC': 49, 'DISC': 51, 'NEGE': 64, 'INTR': 43
        },
        'supplementary_scales': {
            'A': 51, 'R': 36, 'Es': 38, 'Do': 38, 'Re': 37, 'Mt': 57, 'PK': 58, 'MDS': 69, 'Ho': 58, 'O-H': 45, 'MAC-R': 55, 'APS': 65, 'GM': 41, 'GF': 30
        },
        'harris_lingoes_subscales': {
            'D1': 54, 'D2': 50, 'D3': 52, 'D4': 48, 'D5': 56,
            'Hy1': 52, 'Hy2': 48, 'Hy3': 54, 'Hy4': 50, 'Hy5': 49,
            'Pd1': 65, 'Pd2': 58, 'Pd3': 52, 'Pd4': 60, 'Pd5': 55,
            'Pa1': 54, 'Pa2': 52, 'Pa3': 50,
            'Sc1': 58, 'Sc2': 55, 'Sc3': 52, 'Sc4': 54, 'Sc5': 56, 'Sc6': 53,
            'Ma1': 58, 'Ma2': 54, 'Ma3': 52, 'Ma4': 50
        }
    }
    
    return redirect(url_for('generate_report'))

@app.route('/female_sample_data', methods=['GET'])
def female_sample_data():
    """Load female sample data for demonstration."""
    # Sample client info
    session['client_info'] = {
        'name': 'Jane Smith',
        'age': '35',
        'sex': 'female',
        'date': datetime.now().strftime('%Y-%m-%d'),
        'referral_source': 'Dr. John Doe',
        'reason_for_referral': 'Diagnostic clarification and treatment planning'
    }
    
    # Sample scores based on provided screenshots (same T-scores as male sample)
    session['scores'] = {
        'validity_scales': {
            'L': 45, 'F': 51, 'K': 51, 'VRIN': 73, 'TRIN': 57, 'Fb': 51, 'Fp': 56, 'FBS': 43, 'S': 34
        },
        'clinical_scales': {
            'L': 45, 'F': 51, 'K': 51, '1': 51, '2': 51, '3': 51, '4': 68, '5': 62, '6': 53, '7': 44, '8': 56, '9': 56, '0': 44
        },
        'content_scales': {
            'ANX': 62, 'FRS': 67, 'OBS': 53, 'DEP': 55, 'HEA': 56, 'BIZ': 57, 'ANG': 63, 'CYN': 56, 'ASP': 53, 'TPA': 60, 'LSE': 53, 'SOD': 49, 'FAM': 66, 'WRK': 61, 'TRT': 56
        },
        'rc_scales': {
            'RCd': 54, 'RC1': 63, 'RC2': 46, 'RC3': 56, 'RC4': 71, 'RC6': 62, 'RC7': 52, 'RC8': 59, 'RC9': 61
        },
        'psy5_scales': {
            'AGGR': 74, 'PSYC': 49, 'DISC': 51, 'NEGE': 64, 'INTR': 43
        },
        'supplementary_scales': {
            'A': 51, 'R': 36, 'Es': 38, 'Do': 38, 'Re': 37, 'Mt': 57, 'PK': 58, 'MDS': 69, 'Ho': 58, 'O-H': 45, 'MAC-R': 55, 'APS': 65, 'GM': 41, 'GF': 30
        },
        'harris_lingoes_subscales': {
            'D1': 54, 'D2': 50, 'D3': 52, 'D4': 48, 'D5': 56,
            'Hy1': 52, 'Hy2': 48, 'Hy3': 54, 'Hy4': 50, 'Hy5': 49,
            'Pd1': 65, 'Pd2': 58, 'Pd3': 52, 'Pd4': 60, 'Pd5': 55,
            'Pa1': 54, 'Pa2': 52, 'Pa3': 50,
            'Sc1': 58, 'Sc2': 55, 'Sc3': 52, 'Sc4': 54, 'Sc5': 56, 'Sc6': 53,
            'Ma1': 58, 'Ma2': 54, 'Ma3': 52, 'Ma4': 50
        }
    }
    
    return redirect(url_for('generate_report'))

@app.route('/clear_session', methods=['GET'])
def clear_session():
    """Clear session data."""
    session.clear()
    return redirect(url_for('index'))

@app.route('/api/report_data/<report_id>', methods=['GET'])
def report_data(report_id):
    """API endpoint to get report data for Chart.js."""
    report_dir = os.path.join(app.config['REPORT_FOLDER'], report_id)
    
    # Check if report directory exists
    if not os.path.exists(report_dir):
        return jsonify({'error': 'Report not found'}), 404
    
    # Load client info and scores
    with open(os.path.join(report_dir, 'client_info.json'), 'r') as f:
        client_info = json.load(f)
    
    with open(os.path.join(report_dir, 'scores.json'), 'r') as f:
        scores = json.load(f)
    
    return jsonify({
        'client_info': client_info,
        'scores': scores
    })

# Required for Flask deployment
def create_app():
    return app

# For local development
if __name__ == "__main__":
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)

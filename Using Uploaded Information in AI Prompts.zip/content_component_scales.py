"""
Content Component Scales Interpretations for MMPI-2.

This module provides detailed interpretations for MMPI-2 Content Component Scales
based on T-score ranges and gender.
"""

from src.interpretation.component_scales import get_component_scale_interpretation

# Dictionary to map content component scales to their interpretations
CONTENT_COMPONENT_SCALES_INTERPRETATIONS = {}

def get_content_component_scale_interpretation(scale, t_score, gender):
    """
    Get the interpretation for a content component scale based on T-score and gender.
    
    Args:
        scale (str): The content component scale code (e.g., "SOD1", "FAM1", "TRT1")
        t_score (int): The T-score value
        gender (str): "Male" or "Female"
        
    Returns:
        str: The appropriate interpretation text based on T-score range
    """
    # Use the function from component_scales.py to get the interpretation
    return get_component_scale_interpretation(scale, t_score, gender)

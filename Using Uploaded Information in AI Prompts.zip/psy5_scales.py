"""
PSY-5 Scales Interpretations for MMPI-2.

This module provides detailed interpretations for MMPI-2 PSY-5 Scales
based on T-score ranges and gender.
"""

# PSY-5 Scales Interpretations Dictionary
PSY5_SCALES_INTERPRETATIONS = {
    "AGGR": {
        "female": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This female presents with notably low aggressive tendencies. She describes herself as passive, accommodating, and conflict-avoidant in interpersonal situations. She may have difficulty asserting herself appropriately even when warranted. Her interpersonal style emphasizes harmony and agreement, sometimes at the expense of her own needs or rights. She likely avoids confrontation even when it would be adaptive."
                },
                {
                    "range": [46, 55],
                    "interpretation": "This female presents with average aggressive tendencies. She demonstrates appropriate assertiveness in most situations without excessive dominance or hostility. She can advocate for herself when necessary while maintaining respect for others' boundaries and rights. Her interpersonal style balances self-advocacy with cooperation and compromise."
                },
                {
                    "range": [56, 64],
                    "interpretation": "This female presents with moderately elevated aggressive tendencies. She describes herself as assertive, competitive, and willing to engage in conflict when she perceives it as necessary. She may occasionally come across as domineering or intimidating to others, particularly in high-stress situations. Her interpersonal style emphasizes directness and decisive action, sometimes at the expense of collaboration."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female presents with significantly elevated aggressive tendencies. She describes herself as forceful, dominant, and confrontational in interpersonal situations. She frequently engages in power struggles and may use intimidation to achieve her goals. Her interpersonal style emphasizes control and dominance, with limited concern for others' feelings or perspectives. She likely has a history of conflicts across various settings due to her combative approach."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This male presents with notably low aggressive tendencies. He describes himself as passive, accommodating, and conflict-avoidant in interpersonal situations. He may have difficulty asserting himself appropriately even when warranted. His interpersonal style emphasizes harmony and agreement, sometimes at the expense of his own needs or rights. He likely avoids confrontation even when it would be adaptive."
                },
                {
                    "range": [46, 55],
                    "interpretation": "This male presents with average aggressive tendencies. He demonstrates appropriate assertiveness in most situations without excessive dominance or hostility. He can advocate for himself when necessary while maintaining respect for others' boundaries and rights. His interpersonal style balances self-advocacy with cooperation and compromise."
                },
                {
                    "range": [56, 64],
                    "interpretation": "This male presents with moderately elevated aggressive tendencies. He describes himself as assertive, competitive, and willing to engage in conflict when he perceives it as necessary. He may occasionally come across as domineering or intimidating to others, particularly in high-stress situations. His interpersonal style emphasizes directness and decisive action, sometimes at the expense of collaboration."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male presents with significantly elevated aggressive tendencies. He describes himself as forceful, dominant, and confrontational in interpersonal situations. He frequently engages in power struggles and may use intimidation to achieve his goals. His interpersonal style emphasizes control and dominance, with limited concern for others' feelings or perspectives. He likely has a history of conflicts across various settings due to his combative approach."
                }
            ]
        }
    },
    "PSYC": {
        "female": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This female presents with notably low psychotic tendencies. She maintains conventional thought processes and perceptual experiences across various contexts. She demonstrates strong reality testing and does not report unusual beliefs, ideas of reference, or perceptual anomalies. Her thinking remains logical and goal-directed even under stress."
                },
                {
                    "range": [46, 55],
                    "interpretation": "This female presents with average psychotic tendencies. She maintains generally conventional thought processes with occasional creative or unusual thinking that remains within normal limits. She demonstrates adequate reality testing without significant unusual beliefs or perceptual experiences. Her thinking may become temporarily disorganized under extreme stress but quickly returns to baseline."
                },
                {
                    "range": [56, 64],
                    "interpretation": "This female presents with moderately elevated psychotic tendencies. She describes occasional unusual thought processes or perceptual experiences that create some distress or confusion. She may endorse some magical thinking, ideas of reference, or special abilities that exceed conventional beliefs. Her reality testing becomes compromised under stress, with temporary difficulty distinguishing internal from external stimuli."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female presents with significantly elevated psychotic tendencies. She describes frequent unusual thought processes and perceptual experiences that substantially impact her functioning. She endorses magical thinking, ideas of reference, or special abilities that significantly deviate from conventional reality. Her reality testing is compromised even without obvious stressors, with persistent difficulty distinguishing internal from external stimuli. She may report experiences consistent with hallucinations or delusions."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This male presents with notably low psychotic tendencies. He maintains conventional thought processes and perceptual experiences across various contexts. He demonstrates strong reality testing and does not report unusual beliefs, ideas of reference, or perceptual anomalies. His thinking remains logical and goal-directed even under stress."
                },
                {
                    "range": [46, 55],
                    "interpretation": "This male presents with average psychotic tendencies. He maintains generally conventional thought processes with occasional creative or unusual thinking that remains within normal limits. He demonstrates adequate reality testing without significant unusual beliefs or perceptual experiences. His thinking may become temporarily disorganized under extreme stress but quickly returns to baseline."
                },
                {
                    "range": [56, 64],
                    "interpretation": "This male presents with moderately elevated psychotic tendencies. He describes occasional unusual thought processes or perceptual experiences that create some distress or confusion. He may endorse some magical thinking, ideas of reference, or special abilities that exceed conventional beliefs. His reality testing becomes compromised under stress, with temporary difficulty distinguishing internal from external stimuli."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male presents with significantly elevated psychotic tendencies. He describes frequent unusual thought processes and perceptual experiences that substantially impact his functioning. He endorses magical thinking, ideas of reference, or special abilities that significantly deviate from conventional reality. His reality testing is compromised even without obvious stressors, with persistent difficulty distinguishing internal from external stimuli. He may report experiences consistent with hallucinations or delusions."
                }
            ]
        }
    },
    "DISC": {
        "female": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This female presents with notably low disconstraint tendencies. She describes herself as highly controlled, cautious, and rule-adherent. She carefully considers consequences before acting and rarely engages in impulsive behavior. Her approach to life emphasizes planning, responsibility, and conventional values. She may appear overly rigid or inflexible in her adherence to rules and routines."
                },
                {
                    "range": [46, 55],
                    "interpretation": "This female presents with average disconstraint tendencies. She demonstrates appropriate impulse control in most situations while maintaining flexibility when needed. She considers consequences before acting but can be spontaneous when appropriate. Her approach to life balances responsibility with enjoyment and adventure within conventional boundaries."
                },
                {
                    "range": [56, 64],
                    "interpretation": "This female presents with moderately elevated disconstraint tendencies. She describes herself as somewhat impulsive, sensation-seeking, and willing to bend rules when convenient. She may act without fully considering consequences, particularly when pursuing immediate gratification. Her approach to life emphasizes excitement and novelty, sometimes at the expense of stability and long-term planning."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female presents with significantly elevated disconstraint tendencies. She describes herself as highly impulsive, sensation-seeking, and dismissive of conventional rules and constraints. She frequently acts without considering consequences, pursuing immediate gratification despite potential negative outcomes. Her approach to life emphasizes excitement, novelty, and freedom from restrictions, with minimal concern for stability or long-term planning. She likely has a history of risk-taking behaviors across various domains."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This male presents with notably low disconstraint tendencies. He describes himself as highly controlled, cautious, and rule-adherent. He carefully considers consequences before acting and rarely engages in impulsive behavior. His approach to life emphasizes planning, responsibility, and conventional values. He may appear overly rigid or inflexible in his adherence to rules and routines."
                },
                {
                    "range": [46, 55],
                    "interpretation": "This male presents with average disconstraint tendencies. He demonstrates appropriate impulse control in most situations while maintaining flexibility when needed. He considers consequences before acting but can be spontaneous when appropriate. His approach to life balances responsibility with enjoyment and adventure within conventional boundaries."
                },
                {
                    "range": [56, 64],
                    "interpretation": "This male presents with moderately elevated disconstraint tendencies. He describes himself as somewhat impulsive, sensation-seeking, and willing to bend rules when convenient. He may act without fully considering consequences, particularly when pursuing immediate gratification. His approach to life emphasizes excitement and novelty, sometimes at the expense of stability and long-term planning."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This male presents with significantly elevated disconstraint tendencies. He describes himself as highly impulsive, sensation-seeking, and dismissive of conventional rules and constraints. He frequently acts without considering consequences, pursuing immediate gratification despite potential negative outcomes. His approach to life emphasizes excitement, novelty, and freedom from restrictions, with minimal concern for stability or long-term planning. He likely has a history of risk-taking behaviors across various domains."
                }
            ]
        }
    },
    "NEGE": {
        "female": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This female presents with notably low negative emotionality. She describes herself as emotionally stable, resilient, and generally optimistic. She experiences negative emotions infrequently and recovers quickly when they occur. Her emotional landscape is predominantly positive or neutral, with minimal anxiety, worry, or irritability even under stress."
                },
                {
                    "range": [46, 55],
                    "interpretation": "This female presents with average negative emotionality. She experiences an appropriate range of emotions, including periodic negative states that remain proportionate to circumstances. She can manage distressing emotions effectively in most situations and returns to baseline relatively quickly. Her emotional responses generally fit the context and do not significantly interfere with functioning."
                },
                {
                    "range": [56, 64],
                    "interpretation": "This female presents with moderately elevated negative emotionality. She describes herself as somewhat emotionally reactive, with frequent experiences of anxiety, worry, or irritability that exceed situational demands. She has increasing difficulty managing distressing emotions effectively and may take longer to return to baseline. Her emotional responses sometimes seem disproportionate to circumstances and occasionally interfere with functioning."
                },
                {
                    "range": [65, 120],
                    "interpretation": "This female presents with significantly elevated negative emotionality. She describes herself as highly emotionally reactive, with persistent experiences of anxiety, worry, irritability, and other negative emotions that dominate her emotional landscape. She has substantial difficulty managing distressing emotions effectively and may remain dysregulated for extended periods. Her emotional responses frequently seem disproportionate to circumstances and significantly interfere with functioning across multiple domains."
                }
            ]
        },
        "male": {
            "ranges": [
                {
                    "range": [0, 45],
                    "interpretation": "This male presents with notably low negative emotionality. He describes himself as emotionally stable, resilient, and generally opt
(Content truncated due to size limit. Use line ranges to read in chunks)
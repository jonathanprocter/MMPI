"""
MMPI-2 Assessment Platform - Production Configuration
This module provides production-ready WSGI application configuration.
"""

import os
from webapp import app

# Production configuration
app.config.update(
    SECRET_KEY=os.environ.get('SECRET_KEY', 'mmpi2_production_secret_key'),
    DEBUG=False,
    TESTING=False,
    SERVER_NAME=os.environ.get('SERVER_NAME', None)
)

# Ensure report directory exists
if not os.path.exists(app.config['REPORT_FOLDER']):
    os.makedirs(app.config['REPORT_FOLDER'])

# WSGI application
application = app

if __name__ == "__main__":
    # Only for direct execution, not for WSGI servers
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)

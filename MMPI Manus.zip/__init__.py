"""
Initialize the mmpi_platform package.
"""

# Make all modules available for import
__all__ = [
    'src'
]
